-- KYC Verification System Database Updates
-- Add KYC fields to existing clients table and create KYC documents table

-- First, add KYC related fields to the existing iB_clients table
ALTER TABLE `ib_clients` 
ADD COLUMN `kyc_status` ENUM('pending', 'under_review', 'approved', 'rejected') DEFAULT 'pending',
ADD COLUMN `kyc_submitted_at` TIMESTAMP NULL,
ADD COLUMN `kyc_reviewed_at` TIMESTAMP NULL,
ADD COLUMN `kyc_reviewer_id` INT NULL,
ADD COLUMN `kyc_rejection_reason` TEXT NULL,
ADD COLUMN `date_of_birth` DATE NULL,
ADD COLUMN `occupation` VARCHAR(200) NULL,
ADD COLUMN `monthly_income` VARCHAR(100) NULL,
ADD COLUMN `source_of_funds` VARCHAR(200) NULL,
ADD COLUMN `emergency_contact_name` VARCHAR(200) NULL,
ADD COLUMN `emergency_contact_phone` VARCHAR(50) NULL,
ADD COLUMN `emergency_contact_relationship` VARCHAR(100) NULL;

-- Create KYC documents table
CREATE TABLE `ib_kyc_documents` (
  `doc_id` int(20) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `document_type` ENUM('national_id', 'passport', 'drivers_license', 'utility_bill', 'bank_statement', 'selfie', 'signature', 'income_proof') NOT NULL,
  `document_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_size` int(11) NOT NULL,
  `upload_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `verification_status` ENUM('pending', 'verified', 'rejected') DEFAULT 'pending',
  `verified_by` int(11) NULL,
  `verified_at` timestamp NULL,
  `rejection_reason` text NULL,
  PRIMARY KEY (`doc_id`),
  KEY `client_id` (`client_id`),
  FOREIGN KEY (`client_id`) REFERENCES `ib_clients` (`client_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Create KYC verification log table
CREATE TABLE `ib_kyc_log` (
  `log_id` int(20) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `action` varchar(100) NOT NULL,
  `performed_by` int(11) NOT NULL,
  `performer_type` ENUM('admin', 'staff') NOT NULL,
  `details` text NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`log_id`),
  KEY `client_id` (`client_id`),
  FOREIGN KEY (`client_id`) REFERENCES `ib_clients` (`client_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Create KYC requirements table
CREATE TABLE `ib_kyc_requirements` (
  `req_id` int(20) NOT NULL AUTO_INCREMENT,
  `document_type` varchar(100) NOT NULL,
  `is_required` BOOLEAN DEFAULT TRUE,
  `description` text NOT NULL,
  `max_file_size` int(11) DEFAULT 5242880, -- 5MB in bytes
  `allowed_formats` varchar(200) DEFAULT 'jpg,jpeg,png,pdf',
  `display_order` int(3) DEFAULT 0,
  `is_active` BOOLEAN DEFAULT TRUE,
  PRIMARY KEY (`req_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Insert default KYC requirements
INSERT INTO `ib_kyc_requirements` (`document_type`, `description`, `display_order`) VALUES
('national_id', 'Government issued National ID card (front and back)', 1),
('passport', 'Valid passport (bio-data page)', 2),
('drivers_license', 'Valid driver\'s license (front and back)', 3),
('utility_bill', 'Recent utility bill (not older than 3 months)', 4),
('bank_statement', 'Bank statement from another institution (last 3 months)', 5),
('selfie', 'Clear selfie photo holding your ID document', 6),
('income_proof', 'Proof of income (salary slip, business registration, etc.)', 7);
