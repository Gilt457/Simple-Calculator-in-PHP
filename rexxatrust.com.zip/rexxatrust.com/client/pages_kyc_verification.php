<?php
session_start();
include('conf/config.php');
include('conf/checklogin.php');
check_login();
$client_id = $_SESSION['client_id'];

// Handle KYC form submission
if (isset($_POST['submit_kyc'])) {
    $date_of_birth = $_POST['date_of_birth'];
    $occupation = $_POST['occupation'];
    $monthly_income = $_POST['monthly_income'];
    $source_of_funds = $_POST['source_of_funds'];
    $emergency_contact_name = $_POST['emergency_contact_name'];
    $emergency_contact_phone = $_POST['emergency_contact_phone'];
    $emergency_contact_relationship = $_POST['emergency_contact_relationship'];
    
    // Update client information
    $query = "UPDATE iB_clients SET 
              date_of_birth=?, occupation=?, monthly_income=?, source_of_funds=?,
              emergency_contact_name=?, emergency_contact_phone=?, emergency_contact_relationship=?,
              kyc_status='under_review', kyc_submitted_at=NOW() 
              WHERE client_id=?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param('sssssssi', $date_of_birth, $occupation, $monthly_income, $source_of_funds,
                      $emergency_contact_name, $emergency_contact_phone, $emergency_contact_relationship, $client_id);
    $stmt->execute();
    
    if ($stmt) {
        $success = "KYC information submitted successfully. Your documents are under review.";
    } else {
        $err = "Failed to submit KYC information. Please try again.";
    }
}

// Handle document upload
if (isset($_POST['upload_document'])) {
    $document_type = $_POST['document_type'];
    
    if (isset($_FILES['document_file']) && $_FILES['document_file']['error'] == 0) {
        $file_name = $_FILES['document_file']['name'];
        $file_tmp = $_FILES['document_file']['tmp_name'];
        $file_size = $_FILES['document_file']['size'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        
        // Validate file
        $allowed_types = array('jpg', 'jpeg', 'png', 'pdf');
        $max_size = 5 * 1024 * 1024; // 5MB
        
        if (!in_array($file_ext, $allowed_types)) {
            $err = "Invalid file type. Only JPG, JPEG, PNG, and PDF files are allowed.";
        } elseif ($file_size > $max_size) {
            $err = "File is too large. Maximum size is 5MB.";
        } else {
            // Create upload directory if it doesn't exist
            $upload_dir = "dist/kyc_documents/";
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            // Generate unique filename
            $new_filename = $client_id . "_" . $document_type . "_" . time() . "." . $file_ext;
            $file_path = $upload_dir . $new_filename;
            
            if (move_uploaded_file($file_tmp, $file_path)) {
                // Save to database
                $query = "INSERT INTO iB_kyc_documents (client_id, document_type, document_name, file_path, file_size) 
                          VALUES (?, ?, ?, ?, ?)";
                $stmt = $mysqli->prepare($query);
                $stmt->bind_param('isssi', $client_id, $document_type, $file_name, $file_path, $file_size);
                
                if ($stmt->execute()) {
                    $success = "Document uploaded successfully.";
                } else {
                    $err = "Failed to save document information.";
                }
            } else {
                $err = "Failed to upload file.";
            }
        }
    } else {
        $err = "Please select a file to upload.";
    }
}

// Get client information
$ret = "SELECT * FROM iB_clients WHERE client_id = ?";
$stmt = $mysqli->prepare($ret);
$stmt->bind_param('i', $client_id);
$stmt->execute();
$res = $stmt->get_result();
$client = $res->fetch_object();

// Get uploaded documents
$doc_query = "SELECT * FROM iB_kyc_documents WHERE client_id = ? ORDER BY upload_date DESC";
$doc_stmt = $mysqli->prepare($doc_query);
$doc_stmt->bind_param('i', $client_id);
$doc_stmt->execute();
$doc_res = $doc_stmt->get_result();

// Get KYC requirements
$req_query = "SELECT * FROM iB_kyc_requirements WHERE is_active = 1 ORDER BY display_order";
$req_stmt = $mysqli->prepare($req_query);
$req_stmt->execute();
$req_res = $req_stmt->get_result();
?>

<!DOCTYPE html>
<html>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<?php include("dist/_partials/head.php"); ?>

<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed">
    <div class="wrapper">
        <!-- Navbar -->
        <?php include("dist/_partials/nav.php"); ?>
        <!-- Main Sidebar Container -->
        <?php include("dist/_partials/sidebar.php"); ?>

        <!-- Content Wrapper -->
        <div class="content-wrapper">
            <!-- Content Header -->
            <section class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1><i class="fas fa-shield-alt"></i> KYC Verification</h1>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="pages_dashboard.php">Dashboard</a></li>
                                <li class="breadcrumb-item active">KYC Verification</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    
                    <!-- KYC Status Card -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title"><i class="fas fa-info-circle"></i> KYC Status</h3>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <h5>Current Status: 
                                                <?php 
                                                $status = $client->kyc_status ?? 'pending';
                                                switch($status) {
                                                    case 'pending':
                                                        echo '<span class="badge badge-warning">Pending</span>';
                                                        break;
                                                    case 'under_review':
                                                        echo '<span class="badge badge-info">Under Review</span>';
                                                        break;
                                                    case 'approved':
                                                        echo '<span class="badge badge-success">Approved</span>';
                                                        break;
                                                    case 'rejected':
                                                        echo '<span class="badge badge-danger">Rejected</span>';
                                                        break;
                                                }
                                                ?>
                                            </h5>
                                        </div>
                                        <div class="col-md-6">
                                            <?php if ($client->kyc_submitted_at): ?>
                                                <p><strong>Submitted:</strong> <?php echo date('M d, Y H:i', strtotime($client->kyc_submitted_at)); ?></p>
                                            <?php endif; ?>
                                            <?php if ($client->kyc_reviewed_at): ?>
                                                <p><strong>Reviewed:</strong> <?php echo date('M d, Y H:i', strtotime($client->kyc_reviewed_at)); ?></p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    
                                    <?php if ($status == 'rejected' && $client->kyc_rejection_reason): ?>
                                        <div class="alert alert-danger mt-3">
                                            <h6>Rejection Reason:</h6>
                                            <p><?php echo htmlspecialchars($client->kyc_rejection_reason); ?></p>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <?php if ($status == 'pending'): ?>
                                        <div class="alert alert-info mt-3">
                                            <i class="fas fa-info-circle"></i> 
                                            Complete your KYC verification to access all banking services. This process helps us ensure the security of your account.
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php if ($status != 'approved'): ?>
                    <!-- Personal Information Form -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title"><i class="fas fa-user"></i> Personal Information</h3>
                                </div>
                                <div class="card-body">
                                    <form method="post">
                                        <div class="row">
                                            <div class="col-md-6 form-group">
                                                <label>Date of Birth *</label>
                                                <input type="date" name="date_of_birth" class="form-control" 
                                                       value="<?php echo $client->date_of_birth ?? ''; ?>" required>
                                            </div>
                                            <div class="col-md-6 form-group">
                                                <label>Occupation *</label>
                                                <input type="text" name="occupation" class="form-control" 
                                                       value="<?php echo $client->occupation ?? ''; ?>" 
                                                       placeholder="e.g., Software Engineer, Teacher" required>
                                            </div>
                                        </div>
                                        
                                        <div class="row">
                                            <div class="col-md-6 form-group">
                                                <label>Monthly Income Range *</label>
                                                <select name="monthly_income" class="form-control" required>
                                                    <option value="">Select Income Range</option>
                                                    <option value="Below $1,000" <?php echo ($client->monthly_income ?? '') == 'Below $1,000' ? 'selected' : ''; ?>>Below $1,000</option>
                                                    <option value="$1,000 - $2,500" <?php echo ($client->monthly_income ?? '') == '$1,000 - $2,500' ? 'selected' : ''; ?>>$1,000 - $2,500</option>
                                                    <option value="$2,500 - $5,000" <?php echo ($client->monthly_income ?? '') == '$2,500 - $5,000' ? 'selected' : ''; ?>>$2,500 - $5,000</option>
                                                    <option value="$5,000 - $10,000" <?php echo ($client->monthly_income ?? '') == '$5,000 - $10,000' ? 'selected' : ''; ?>>$5,000 - $10,000</option>
                                                    <option value="Above $10,000" <?php echo ($client->monthly_income ?? '') == 'Above $10,000' ? 'selected' : ''; ?>>Above $10,000</option>
                                                </select>
                                            </div>
                                            <div class="col-md-6 form-group">
                                                <label>Source of Funds *</label>
                                                <select name="source_of_funds" class="form-control" required>
                                                    <option value="">Select Source</option>
                                                    <option value="Salary/Employment" <?php echo ($client->source_of_funds ?? '') == 'Salary/Employment' ? 'selected' : ''; ?>>Salary/Employment</option>
                                                    <option value="Business Income" <?php echo ($client->source_of_funds ?? '') == 'Business Income' ? 'selected' : ''; ?>>Business Income</option>
                                                    <option value="Investment Returns" <?php echo ($client->source_of_funds ?? '') == 'Investment Returns' ? 'selected' : ''; ?>>Investment Returns</option>
                                                    <option value="Inheritance" <?php echo ($client->source_of_funds ?? '') == 'Inheritance' ? 'selected' : ''; ?>>Inheritance</option>
                                                    <option value="Other" <?php echo ($client->source_of_funds ?? '') == 'Other' ? 'selected' : ''; ?>>Other</option>
                                                </select>
                                            </div>
                                        </div>

                                        <h5 class="mt-4"><i class="fas fa-phone"></i> Emergency Contact</h5>
                                        <div class="row">
                                            <div class="col-md-4 form-group">
                                                <label>Emergency Contact Name *</label>
                                                <input type="text" name="emergency_contact_name" class="form-control" 
                                                       value="<?php echo $client->emergency_contact_name ?? ''; ?>" required>
                                            </div>
                                            <div class="col-md-4 form-group">
                                                <label>Emergency Contact Phone *</label>
                                                <input type="tel" name="emergency_contact_phone" class="form-control" 
                                                       value="<?php echo $client->emergency_contact_phone ?? ''; ?>" required>
                                            </div>
                                            <div class="col-md-4 form-group">
                                                <label>Relationship *</label>
                                                <select name="emergency_contact_relationship" class="form-control" required>
                                                    <option value="">Select Relationship</option>
                                                    <option value="Spouse" <?php echo ($client->emergency_contact_relationship ?? '') == 'Spouse' ? 'selected' : ''; ?>>Spouse</option>
                                                    <option value="Parent" <?php echo ($client->emergency_contact_relationship ?? '') == 'Parent' ? 'selected' : ''; ?>>Parent</option>
                                                    <option value="Child" <?php echo ($client->emergency_contact_relationship ?? '') == 'Child' ? 'selected' : ''; ?>>Child</option>
                                                    <option value="Sibling" <?php echo ($client->emergency_contact_relationship ?? '') == 'Sibling' ? 'selected' : ''; ?>>Sibling</option>
                                                    <option value="Friend" <?php echo ($client->emergency_contact_relationship ?? '') == 'Friend' ? 'selected' : ''; ?>>Friend</option>
                                                    <option value="Other" <?php echo ($client->emergency_contact_relationship ?? '') == 'Other' ? 'selected' : ''; ?>>Other</option>
                                                </select>
                                            </div>
                                        </div>

                                        <button type="submit" name="submit_kyc" class="btn btn-primary">
                                            <i class="fas fa-save"></i> Save Information
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Document Upload Section -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title"><i class="fas fa-upload"></i> Document Upload</h3>
                                </div>
                                <div class="card-body">
                                    <div class="alert alert-info">
                                        <i class="fas fa-info-circle"></i>
                                        <strong>Upload Requirements:</strong>
                                        <ul class="mb-0 mt-2">
                                            <li>File formats: JPG, JPEG, PNG, PDF</li>
                                            <li>Maximum file size: 5MB</li>
                                            <li>Documents should be clear and readable</li>
                                            <li>Personal information must be visible</li>
                                        </ul>
                                    </div>

                                    <form method="post" enctype="multipart/form-data" class="mb-4">
                                        <div class="row">
                                            <div class="col-md-4 form-group">
                                                <label>Document Type *</label>
                                                <select name="document_type" class="form-control" required>
                                                    <option value="">Select Document Type</option>
                                                    <?php while ($req = $req_res->fetch_object()): ?>
                                                        <option value="<?php echo $req->document_type; ?>">
                                                            <?php echo ucwords(str_replace('_', ' ', $req->document_type)); ?>
                                                        </option>
                                                    <?php endwhile; ?>
                                                </select>
                                            </div>
                                            <div class="col-md-6 form-group">
                                                <label>Choose File *</label>
                                                <input type="file" name="document_file" class="form-control" 
                                                       accept=".jpg,.jpeg,.png,.pdf" required>
                                            </div>
                                            <div class="col-md-2 form-group">
                                                <label>&nbsp;</label>
                                                <button type="submit" name="upload_document" class="btn btn-success btn-block">
                                                    <i class="fas fa-upload"></i> Upload
                                                </button>
                                            </div>
                                        </div>
                                    </form>

                                    <!-- Uploaded Documents -->
                                    <h5><i class="fas fa-file-alt"></i> Uploaded Documents</h5>
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-striped">
                                            <thead>
                                                <tr>
                                                    <th>Document Type</th>
                                                    <th>File Name</th>
                                                    <th>Upload Date</th>
                                                    <th>Status</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php if ($doc_res->num_rows > 0): ?>
                                                    <?php while ($doc = $doc_res->fetch_object()): ?>
                                                        <tr>
                                                            <td><?php echo ucwords(str_replace('_', ' ', $doc->document_type)); ?></td>
                                                            <td><?php echo htmlspecialchars($doc->document_name); ?></td>
                                                            <td><?php echo date('M d, Y H:i', strtotime($doc->upload_date)); ?></td>
                                                            <td>
                                                                <?php
                                                                switch($doc->verification_status) {
                                                                    case 'pending':
                                                                        echo '<span class="badge badge-warning">Pending</span>';
                                                                        break;
                                                                    case 'verified':
                                                                        echo '<span class="badge badge-success">Verified</span>';
                                                                        break;
                                                                    case 'rejected':
                                                                        echo '<span class="badge badge-danger">Rejected</span>';
                                                                        break;
                                                                }
                                                                ?>
                                                            </td>
                                                            <td>
                                                                <a href="<?php echo $doc->file_path; ?>" target="_blank" class="btn btn-sm btn-info">
                                                                    <i class="fas fa-eye"></i> View
                                                                </a>
                                                            </td>
                                                        </tr>
                                                    <?php endwhile; ?>
                                                <?php else: ?>
                                                    <tr>
                                                        <td colspan="5" class="text-center">No documents uploaded yet.</td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php else: ?>
                    <!-- KYC Approved Message -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card border-success">
                                <div class="card-body text-center">
                                    <i class="fas fa-check-circle text-success" style="font-size: 4rem;"></i>
                                    <h3 class="text-success mt-3">KYC Verification Completed!</h3>
                                    <p class="lead">Your identity has been successfully verified. You now have full access to all banking services.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>

                </div>
            </section>
        </div>

        <?php include("dist/_partials/footer.php"); ?>
    </div>

    <!-- Scripts -->
    <script src="plugins/jquery/jquery.min.js"></script>
    <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="dist/js/adminlte.min.js"></script>

    <script>
        // File upload validation
        $('input[type="file"]').change(function() {
            var file = this.files[0];
            var maxSize = 5 * 1024 * 1024; // 5MB
            
            if (file) {
                if (file.size > maxSize) {
                    alert('File is too large. Maximum size is 5MB.');
                    $(this).val('');
                    return false;
                }
                
                var allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'application/pdf'];
                if (allowedTypes.indexOf(file.type) === -1) {
                    alert('Invalid file type. Only JPG, JPEG, PNG, and PDF files are allowed.');
                    $(this).val('');
                    return false;
                }
            }
        });
    </script>
</body>
</html>
