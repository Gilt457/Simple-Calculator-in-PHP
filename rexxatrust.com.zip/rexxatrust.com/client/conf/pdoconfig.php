<?php
$DB_host = "localhost";
$DB_user = "u770501530_junior";
$DB_pass = " @Dollar2024";
$DB_name = "u770501530_banking";
try
{
 $DB_con = new PDO("mysql:host={$DB_host};dbname={$DB_name}",$DB_user,$DB_pass);
 $DB_con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $e)
{
 $e->getMessage();
}
