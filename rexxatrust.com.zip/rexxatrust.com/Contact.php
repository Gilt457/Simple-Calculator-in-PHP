<?php
include("admin/conf/config.php");
/* Persist System Settings On Brand */
$ret = "SELECT * FROM `iB_SystemSettings` ";
$stmt = $mysqli->prepare($ret);
$stmt->execute();
$res = $stmt->get_result();
while ($sys = $res->fetch_object()) {
?>
    <!DOCTYPE html>
    <html lang="en">
    <meta http-equiv="content-type" content="text/html;charset=utf-8" />

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="Learn more about <?php echo $sys->sys_name; ?>, our mission, vision, and values.">
        <meta name="author" content="">
        <title>Contact Us - <?php echo $sys->sys_name; ?></title>
        <link href="dist/css/custom.css" rel="stylesheet">
        <link href="dist/css/robust.css" rel="stylesheet">
        <link href="dist/css/about us.css" rel="stylesheet">
        <link href="dist/css/contact.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    </head>

    <body>

        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark py-3">
            <div class="container">
                <a class="navbar-brand font-weight-bold" href="index.php"><?php echo $sys->sys_name; ?></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <ul class="navbar-nav ml-auto align-items-center">
                        <li class="nav-item">
                            <a class="nav-link text-white" href="index.php">Home</a>
                        </li>                        <li class="nav-item">
                            <a class="nav-link text-white" href="About us.php">About Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="reviews.php">Reviews</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="Contact.php">Contact Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" target="_blank" href="admin/pages_index.php">Admin Portal</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" target="_blank" href="staff/pages_staff_index.php">Staff Portal</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" target="_blank" href="client/pages_client_index.php">Client Portal</a>
                        </li>
                    </ul>
                    <a class="btn btn-danger ml-3" href="client/pages_client_signup.php" target="_blank">Join Us</a>
                </div>
            </div>
        </nav>

        <!-- Contact Us Section -->
        <div class="contact-us py-4 position-relative text-white" style="background-color: #343a40;">
            <div class="contact-content py-4 text-center">
                <div class="container">
                    <h1 class="my-3 display-5">Contact Us</h1>
                    <p class="lead mb-2">We'd love to hear from you. Reach out to us with any questions or feedback.</p>                    <div class="mt-4">
                        <p>Email: info@rexxatrust.com</p>
                        <p>Phone: +1 (386) 703-5135</p>
                        <p>Address: 1020 Kinney St, Richmond, VA 23220</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Contact Information Cards Section -->
        <div class="contact-info-section py-5 bg-light">
            <div class="container">
                <h2 class="text-center mb-5">Get In Touch With Us</h2>
                <div class="row">
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="contact-card text-center p-4 bg-white shadow-sm rounded">
                            <div class="contact-icon mb-3">
                                <i class="fas fa-map-marker-alt fa-2x text-primary"></i>
                            </div>                            <h5>Visit Our Office</h5>
                            <p>1020 Kinney St<br>Richmond, VA 23220<br>United States</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="contact-card text-center p-4 bg-white shadow-sm rounded">
                            <div class="contact-icon mb-3">
                                <i class="fas fa-phone fa-2x text-primary"></i>
                            </div>
                            <h5>Call Us</h5>
                            <p>Main: +1 (386) 703-5135<br>Support: +1 (386) 703-5135<br>Mon-Fri: 9AM-6PM</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="contact-card text-center p-4 bg-white shadow-sm rounded">
                            <div class="contact-icon mb-3">
                                <i class="fas fa-envelope fa-2x text-primary"></i>
                            </div>                            <h5>Email Us</h5>
                            <p>General: info@rexxatrust.com<br>Support: info@rexxatrust.com<br>Business: info@rexxatrust.com</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Department Contact Section -->
        <div class="department-contact-section py-5">
            <div class="container">
                <h2 class="text-center mb-5">Contact by Department</h2>
                <div class="row">
                    <div class="col-lg-3 col-md-6 mb-4">
                        <div class="department-card p-4 border rounded h-100">
                            <i class="fas fa-user-tie fa-2x text-primary mb-3"></i>
                            <h5>Customer Service</h5>
                            <p>For general inquiries and account assistance</p>                            <small class="text-muted">+1 (386) 703-5135<br>info@rexxatrust.com</small>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 mb-4">
                        <div class="department-card p-4 border rounded h-100">
                            <i class="fas fa-credit-card fa-2x text-primary mb-3"></i>
                            <h5>Loans Department</h5>
                            <p>Personal, business, and mortgage loans</p>
                            <small class="text-muted">+1 (386) 703-5135<br>info@rexxatrust.com</small>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 mb-4">
                        <div class="department-card p-4 border rounded h-100">
                            <i class="fas fa-chart-line fa-2x text-primary mb-3"></i>
                            <h5>Investment Services</h5>
                            <p>Investment advice and portfolio management</p>
                            <small class="text-muted">+1 (386) 703-5135<br>info@rexxatrust.com</small>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 mb-4">
                        <div class="department-card p-4 border rounded h-100">
                            <i class="fas fa-shield-alt fa-2x text-primary mb-3"></i>
                            <h5>Security & Fraud</h5>
                            <p>Report suspicious activity or security concerns</p>
                            <small class="text-muted">+1 (386) 703-5135<br>info@rexxatrust.com</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Business Hours Section -->
        <div class="business-hours-section py-5 bg-light">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 mb-4">
                        <h3>Business Hours</h3>
                        <div class="hours-table">
                            <div class="d-flex justify-content-between border-bottom py-2">
                                <span><strong>Monday - Friday</strong></span>
                                <span>9:00 AM - 6:00 PM</span>
                            </div>
                            <div class="d-flex justify-content-between border-bottom py-2">
                                <span><strong>Saturday</strong></span>
                                <span>9:00 AM - 2:00 PM</span>
                            </div>
                            <div class="d-flex justify-content-between border-bottom py-2">
                                <span><strong>Sunday</strong></span>
                                <span>Closed</span>
                            </div>
                            <div class="d-flex justify-content-between py-2">
                                <span><strong>Holidays</strong></span>
                                <span>Limited Hours</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 mb-4">
                        <h3>24/7 Services Available</h3>
                        <ul class="list-unstyled">
                            <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Online Banking</li>
                            <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Mobile Banking App</li>
                            <li class="mb-2"><i class="fas fa-check text-success me-2"></i> ATM Services</li>
                            <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Emergency Card Services</li>
                            <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Fraud Reporting Hotline</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <!-- FAQ Section -->
        <div class="faq-section py-5">
            <div class="container">
                <h2 class="text-center mb-5">Frequently Asked Questions</h2>
                <div class="row">
                    <div class="col-lg-8 mx-auto">
                        <div class="accordion" id="faqAccordion">
                            <div class="card mb-3">
                                <div class="card-header" id="faq1">
                                    <h5 class="mb-0">
                                        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapse1">
                                            How can I reset my online banking password?
                                        </button>
                                    </h5>
                                </div>
                                <div id="collapse1" class="collapse" data-parent="#faqAccordion">                                    <div class="card-body">
                                        You can reset your password by clicking "Forgot Password" on the login page or contact our customer service at +1 (386) 703-5135.
                                    </div>
                                </div>
                            </div>
                            <div class="card mb-3">
                                <div class="card-header" id="faq2">
                                    <h5 class="mb-0">
                                        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapse2">
                                            What are your loan interest rates?
                                        </button>
                                    </h5>
                                </div>
                                <div id="collapse2" class="collapse" data-parent="#faqAccordion">
                                    <div class="card-body">
                                        Our loan rates vary based on loan type and credit score. Contact our loans department at +1 (386) 703-5135 for current rates.
                                    </div>
                                </div>
                            </div>
                            <div class="card mb-3">
                                <div class="card-header" id="faq3">
                                    <h5 class="mb-0">
                                        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapse3">
                                            How do I report a lost or stolen card?
                                        </button>
                                    </h5>
                                </div>
                                <div id="collapse3" class="collapse" data-parent="#faqAccordion">
                                    <div class="card-body">
                                        Call our 24/7 emergency line at +1 (386) 703-5135 immediately to report and block your card.
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Google Map Section -->
        <div class="google-map-section py-4">
            <div class="container">
                <h2 class="text-center mb-4">Find Us Here</h2>                <div class="map-container">
                    <iframe
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3153.835434509374!2d-77.4609!3d37.5407!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89b111b9eab72acf%3A0x4a0b8e8b8b8b8b8b!2s1020%20Kinney%20St%2C%20Richmond%2C%20VA%2023220!5e0!3m2!1sen!2sus!4v1610000000000!5m2!1sen!2sus"
                        width="100%"
                        height="400"
                        style="border:0;"
                        allowfullscreen=""
                        loading="lazy">
                    </iframe>
                </div>
            </div>
        </div>

        <!-- Contact Us Form Section -->
        <div class="contact-form-section py-5 bg-light">
            <div class="container">
                <h2 class="text-center mb-4">Send Us a Message</h2>
                <div class="row">
                    <div class="col-lg-8 mx-auto">
                        <form action="process_contact_form.php" method="POST" class="contact-form">
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="name">Full Name</label>
                                    <input type="text" class="form-control" id="name" name="name" placeholder="Enter your full name" required>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="email">Email Address</label>
                                    <input type="email" class="form-control" id="email" name="email" placeholder="Enter your email" required>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="phone">Phone Number</label>
                                    <input type="tel" class="form-control" id="phone" name="phone" placeholder="Enter your phone number">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="department">Department</label>
                                    <select class="form-control" id="department" name="department">
                                        <option value="">Select Department</option>
                                        <option value="general">General Inquiry</option>
                                        <option value="customer-service">Customer Service</option>
                                        <option value="loans">Loans</option>
                                        <option value="investments">Investments</option>
                                        <option value="security">Security/Fraud</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="subject">Subject</label>
                                <input type="text" class="form-control" id="subject" name="subject" placeholder="Enter the subject" required>
                            </div>
                            <div class="form-group">
                                <label for="message">Message</label>
                                <textarea class="form-control" id="message" name="message" rows="5" placeholder="Write your message here" required></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary btn-block">Send Message</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Emergency Contact Section -->
        <div class="emergency-contact-section py-4 bg-danger text-white">
            <div class="container text-center">
                <h3><i class="fas fa-exclamation-triangle me-2"></i>Emergency Banking Support</h3>
                <p class="mb-2">For urgent banking matters, card issues, or fraud reporting</p>
                <h4><a href="tel:+11234567894" class="text-white">+1(386)703-5135</a></h4>
                <small>Available 24/7</small>
            </div>
        </div>

        <!-- Footer Section -->
        <footer class="footer bg-dark text-white py-4">
            <div class="container">
                <div class="row">                    <!-- About Section -->
                    <div class="col-lg-4 col-md-6 mb-4">
                        <h5 class="footer-title">About Rexxa Trust</h5>
                        <p>Rexxa Trust is committed to providing secure and reliable banking services to help you manage your finances with ease.</p>
                    </div>
                    <!-- Quick Links -->
                    <div class="col-lg-4 col-md-6 mb-4">
                        <h5 class="footer-title">Quick Links</h5>
                        <ul class="footer-links list-unstyled">
                            <li><a href="index.php" class="text-white">Home</a></li>
                            <li><a href="About us.php" class="text-white">About Us</a></li>
                            <li><a href="Contact.php" class="text-white">Contact Us</a></li>
                            <li><a href="https://rexxatrust.com/client/pages_client_signup.php" class="text-white">Sign Up</a></li>
                        </ul>
                    </div>
                    <!-- Social Media -->
                    <div class="col-lg-4 col-md-12 mb-4">
                        <h5 class="footer-title">Follow Us</h5>
                        <div class="social-icons">
                            <a href="#" class="text-white me-3"><i class="fab fa-facebook-f"></i></a>
                            <a href="#" class="text-white me-3"><i class="fab fa-twitter"></i></a>
                            <a href="#" class="text-white me-3"><i class="fab fa-instagram"></i></a>
                            <a href="#" class="text-white"><i class="fab fa-linkedin-in"></i></a>
                        </div>
                    </div>
                </div>                <div class="row mt-4">
                    <div class="col-12 text-center">
                        <p class="mb-0">&copy; <?php echo date('Y'); ?> Rexxa Trust. All Rights Reserved.</p>
                    </div>
                </div>
            </div>
        </footer>

        <!-- Bootstrap JS -->
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>

    </body>
<?php
} // Close the while loop
?>