<?php
    $dbuser="u770501530_junior";
    $dbpass="@Dollar2024";
    $host="localhost";
    $db="u770501530_banking";
    $mysqli=new mysqli($host,$dbuser, $dbpass, $db);
