<?php
session_start();
include('conf/config.php');
include('conf/checklogin.php');
check_login();
$admin_id = $_SESSION['admin_id'];

// Handle KYC approval/rejection
if (isset($_POST['update_kyc_status'])) {
    $client_id = $_POST['client_id'];
    $status = $_POST['status'];
    $rejection_reason = $_POST['rejection_reason'] ?? null;
    
    $query = "UPDATE iB_clients SET kyc_status=?, kyc_reviewed_at=NOW(), kyc_reviewer_id=?, kyc_rejection_reason=? WHERE client_id=?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param('sisi', $status, $admin_id, $rejection_reason, $client_id);
    
    if ($stmt->execute()) {
        // Log the action
        $log_query = "INSERT INTO iB_kyc_log (client_id, action, performed_by, performer_type, details) VALUES (?, ?, ?, 'admin', ?)";
        $log_stmt = $mysqli->prepare($log_query);
        $action = "KYC " . ucfirst($status);
        $details = $status == 'rejected' ? "Reason: " . $rejection_reason : "KYC verification " . $status;
        $log_stmt->bind_param('isis', $client_id, $action, $admin_id, $details);
        $log_stmt->execute();
        
        $success = "KYC status updated successfully.";
    } else {
        $err = "Failed to update KYC status.";
    }
}

// Handle document verification
if (isset($_POST['verify_document'])) {
    $doc_id = $_POST['doc_id'];
    $verification_status = $_POST['verification_status'];
    $rejection_reason = $_POST['document_rejection_reason'] ?? null;
    
    $query = "UPDATE iB_kyc_documents SET verification_status=?, verified_by=?, verified_at=NOW(), rejection_reason=? WHERE doc_id=?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param('sisi', $verification_status, $admin_id, $rejection_reason, $doc_id);
    
    if ($stmt->execute()) {
        $success = "Document verification status updated.";
    } else {
        $err = "Failed to update document status.";
    }
}

// Get filter parameters
$status_filter = $_GET['status'] ?? 'all';
$search = $_GET['search'] ?? '';

// Build query for clients
$where_clause = "WHERE 1=1";
$params = [];
$types = "";

if ($status_filter != 'all') {
    $where_clause .= " AND kyc_status = ?";
    $params[] = $status_filter;
    $types .= "s";
}

if (!empty($search)) {
    $where_clause .= " AND (name LIKE ? OR email LIKE ? OR client_number LIKE ?)";
    $search_term = "%$search%";
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
    $types .= "sss";
}

$query = "SELECT * FROM iB_clients $where_clause ORDER BY kyc_submitted_at DESC, client_id DESC";
$stmt = $mysqli->prepare($query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$clients_result = $stmt->get_result();

// Get KYC statistics
$stats_query = "SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN kyc_status = 'pending' THEN 1 ELSE 0 END) as pending,
    SUM(CASE WHEN kyc_status = 'under_review' THEN 1 ELSE 0 END) as under_review,
    SUM(CASE WHEN kyc_status = 'approved' THEN 1 ELSE 0 END) as approved,
    SUM(CASE WHEN kyc_status = 'rejected' THEN 1 ELSE 0 END) as rejected
    FROM iB_clients";
$stats_result = $mysqli->query($stats_query);
$stats = $stats_result->fetch_object();
?>

<!DOCTYPE html>
<html>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<?php include("dist/_partials/head.php"); ?>

<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed">
    <div class="wrapper">
        <!-- Navbar -->
        <?php include("dist/_partials/nav.php"); ?>
        <!-- Main Sidebar Container -->
        <?php include("dist/_partials/sidebar.php"); ?>

        <!-- Content Wrapper -->
        <div class="content-wrapper">
            <!-- Content Header -->
            <section class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1><i class="fas fa-shield-alt"></i> KYC Management</h1>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="pages_dashboard.php">Dashboard</a></li>
                                <li class="breadcrumb-item active">KYC Management</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    
                    <!-- Statistics Cards -->
                    <div class="row">
                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-info">
                                <div class="inner">
                                    <h3><?php echo $stats->total; ?></h3>
                                    <p>Total Clients</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-users"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-warning">
                                <div class="inner">
                                    <h3><?php echo $stats->pending + $stats->under_review; ?></h3>
                                    <p>Pending Review</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-clock"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-success">
                                <div class="inner">
                                    <h3><?php echo $stats->approved; ?></h3>
                                    <p>Approved</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-check-circle"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-danger">
                                <div class="inner">
                                    <h3><?php echo $stats->rejected; ?></h3>
                                    <p>Rejected</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-times-circle"></i>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Filters -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title"><i class="fas fa-filter"></i> Filters</h3>
                                </div>
                                <div class="card-body">
                                    <form method="GET" class="row">
                                        <div class="col-md-4 form-group">
                                            <label>KYC Status</label>
                                            <select name="status" class="form-control">
                                                <option value="all">All Status</option>
                                                <option value="pending" <?php echo $status_filter == 'pending' ? 'selected' : ''; ?>>Pending</option>
                                                <option value="under_review" <?php echo $status_filter == 'under_review' ? 'selected' : ''; ?>>Under Review</option>
                                                <option value="approved" <?php echo $status_filter == 'approved' ? 'selected' : ''; ?>>Approved</option>
                                                <option value="rejected" <?php echo $status_filter == 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                                            </select>
                                        </div>
                                        <div class="col-md-6 form-group">
                                            <label>Search</label>
                                            <input type="text" name="search" class="form-control" 
                                                   placeholder="Search by name, email, or client number..." 
                                                   value="<?php echo htmlspecialchars($search); ?>">
                                        </div>
                                        <div class="col-md-2 form-group">
                                            <label>&nbsp;</label>
                                            <button type="submit" class="btn btn-primary btn-block">
                                                <i class="fas fa-search"></i> Filter
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Clients Table -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title"><i class="fas fa-list"></i> KYC Verification Requests</h3>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-striped">
                                            <thead>
                                                <tr>
                                                    <th>Client Info</th>
                                                    <th>Contact Details</th>
                                                    <th>KYC Status</th>
                                                    <th>Submission Date</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php if ($clients_result->num_rows > 0): ?>
                                                    <?php while ($client = $clients_result->fetch_object()): ?>
                                                        <tr>
                                                            <td>
                                                                <strong><?php echo htmlspecialchars($client->name); ?></strong><br>
                                                                <small class="text-muted"><?php echo $client->client_number; ?></small><br>
                                                                <small class="text-muted">ID: <?php echo $client->national_id; ?></small>
                                                            </td>
                                                            <td>
                                                                <?php echo htmlspecialchars($client->email); ?><br>
                                                                <small class="text-muted"><?php echo $client->phone; ?></small>
                                                            </td>
                                                            <td>
                                                                <?php
                                                                $status = $client->kyc_status ?? 'pending';
                                                                switch($status) {
                                                                    case 'pending':
                                                                        echo '<span class="badge badge-warning">Pending</span>';
                                                                        break;
                                                                    case 'under_review':
                                                                        echo '<span class="badge badge-info">Under Review</span>';
                                                                        break;
                                                                    case 'approved':
                                                                        echo '<span class="badge badge-success">Approved</span>';
                                                                        break;
                                                                    case 'rejected':
                                                                        echo '<span class="badge badge-danger">Rejected</span>';
                                                                        break;
                                                                }
                                                                ?>
                                                                <?php if ($client->kyc_rejection_reason): ?>
                                                                    <br><small class="text-danger"><?php echo htmlspecialchars($client->kyc_rejection_reason); ?></small>
                                                                <?php endif; ?>
                                                            </td>
                                                            <td>
                                                                <?php echo $client->kyc_submitted_at ? date('M d, Y H:i', strtotime($client->kyc_submitted_at)) : 'Not submitted'; ?>
                                                            </td>
                                                            <td>
                                                                <a href="pages_kyc_review.php?client_id=<?php echo $client->client_id; ?>" 
                                                                   class="btn btn-sm btn-info">
                                                                    <i class="fas fa-eye"></i> Review
                                                                </a>
                                                                <?php if ($status == 'under_review'): ?>
                                                                <button type="button" class="btn btn-sm btn-success" 
                                                                        onclick="updateKYCStatus(<?php echo $client->client_id; ?>, 'approved')">
                                                                    <i class="fas fa-check"></i> Approve
                                                                </button>
                                                                <button type="button" class="btn btn-sm btn-danger" 
                                                                        onclick="showRejectModal(<?php echo $client->client_id; ?>)">
                                                                    <i class="fas fa-times"></i> Reject
                                                                </button>
                                                                <?php endif; ?>
                                                            </td>
                                                        </tr>
                                                    <?php endwhile; ?>
                                                <?php else: ?>
                                                    <tr>
                                                        <td colspan="5" class="text-center">No clients found.</td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </section>
        </div>

        <?php include("dist/_partials/footer.php"); ?>
    </div>

    <!-- Rejection Modal -->
    <div class="modal fade" id="rejectModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Reject KYC Verification</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="client_id" id="reject_client_id">
                        <input type="hidden" name="status" value="rejected">
                        <div class="form-group">
                            <label>Rejection Reason *</label>
                            <textarea name="rejection_reason" class="form-control" rows="4" 
                                      placeholder="Please provide a clear reason for rejection..." required></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        <button type="submit" name="update_kyc_status" class="btn btn-danger">Reject KYC</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="plugins/jquery/jquery.min.js"></script>
    <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="dist/js/adminlte.min.js"></script>

    <script>
        function updateKYCStatus(clientId, status) {
            if (confirm('Are you sure you want to ' + status + ' this KYC verification?')) {
                var form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = 
                    '<input type="hidden" name="client_id" value="' + clientId + '">' +
                    '<input type="hidden" name="status" value="' + status + '">' +
                    '<input type="hidden" name="update_kyc_status" value="1">';
                document.body.appendChild(form);
                form.submit();
            }
        }

        function showRejectModal(clientId) {
            document.getElementById('reject_client_id').value = clientId;
            $('#rejectModal').modal('show');
        }
    </script>
</body>
</html>
