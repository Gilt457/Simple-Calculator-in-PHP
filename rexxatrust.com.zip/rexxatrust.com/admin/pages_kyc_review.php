<?php
session_start();
include('conf/config.php');
include('conf/checklogin.php');
include('../includes/kyc_email_config.php');
check_login();
$admin_id = $_SESSION['admin_id'];

$client_id = $_GET['client_id'] ?? 0;

// Get client information
$client_query = "SELECT * FROM iB_clients WHERE client_id = ?";
$client_stmt = $mysqli->prepare($client_query);
$client_stmt->bind_param('i', $client_id);
$client_stmt->execute();
$client_result = $client_stmt->get_result();

if ($client_result->num_rows == 0) {
    header("Location: pages_kyc_management.php");
    exit();
}

$client = $client_result->fetch_object();

// Get client documents
$docs_query = "SELECT * FROM iB_kyc_documents WHERE client_id = ? ORDER BY upload_date DESC";
$docs_stmt = $mysqli->prepare($docs_query);
$docs_stmt->bind_param('i', $client_id);
$docs_stmt->execute();
$docs_result = $docs_stmt->get_result();

// Get KYC activity log
$log_query = "SELECT l.*, a.name as admin_name, s.name as staff_name 
              FROM iB_kyc_log l
              LEFT JOIN iB_admin a ON l.performed_by = a.admin_id AND l.performer_type = 'admin'
              LEFT JOIN iB_staff s ON l.performed_by = s.staff_id AND l.performer_type = 'staff'
              WHERE l.client_id = ? 
              ORDER BY l.timestamp DESC";
$log_stmt = $mysqli->prepare($log_query);
$log_stmt->bind_param('i', $client_id);
$log_stmt->execute();
$log_result = $log_stmt->get_result();

// Handle KYC status update
if (isset($_POST['update_kyc_status'])) {
    $status = $_POST['status'];
    $rejection_reason = $_POST['rejection_reason'] ?? null;
    
    $update_query = "UPDATE iB_clients SET kyc_status=?, kyc_reviewed_at=NOW(), kyc_reviewer_id=?, kyc_rejection_reason=? WHERE client_id=?";
    $update_stmt = $mysqli->prepare($update_query);
    $update_stmt->bind_param('sisi', $status, $admin_id, $rejection_reason, $client_id);
      if ($update_stmt->execute()) {
        // Log the action
        $log_insert = "INSERT INTO iB_kyc_log (client_id, action, performed_by, performer_type, details) VALUES (?, ?, ?, 'admin', ?)";
        $log_stmt = $mysqli->prepare($log_insert);
        $action = "KYC " . ucfirst($status);
        $details = $status == 'rejected' ? "Reason: " . $rejection_reason : "KYC verification " . $status;
        $log_stmt->bind_param('isis', $client_id, $action, $admin_id, $details);
        $log_stmt->execute();
        
        // Send email notification
        $email_sent = sendKYCNotification($client->email, $client->name, $status, $rejection_reason);
        logKYCEmail($client_id, $status, $client->email, $email_sent);
        
        $success = "KYC status updated successfully." . ($email_sent ? " Email notification sent." : " (Email notification failed)");
        
        // Refresh client data
        $client_stmt->execute();
        $client_result = $client_stmt->get_result();
        $client = $client_result->fetch_object();
    } else {
        $err = "Failed to update KYC status.";
    }
}

// Handle document verification
if (isset($_POST['verify_document'])) {
    $doc_id = $_POST['doc_id'];
    $verification_status = $_POST['verification_status'];
    $rejection_reason = $_POST['document_rejection_reason'] ?? null;
    
    $verify_query = "UPDATE iB_kyc_documents SET verification_status=?, verified_by=?, verified_at=NOW(), rejection_reason=? WHERE doc_id=?";
    $verify_stmt = $mysqli->prepare($verify_query);
    $verify_stmt->bind_param('sisi', $verification_status, $admin_id, $rejection_reason, $doc_id);
    
    if ($verify_stmt->execute()) {
        $success = "Document verification status updated.";
        
        // Refresh documents data
        $docs_stmt->execute();
        $docs_result = $docs_stmt->get_result();
    } else {
        $err = "Failed to update document status.";
    }
}
?>

<!DOCTYPE html>
<html>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<?php include("dist/_partials/head.php"); ?>

<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed">
    <div class="wrapper">
        <!-- Navbar -->
        <?php include("dist/_partials/nav.php"); ?>
        <!-- Main Sidebar Container -->
        <?php include("dist/_partials/sidebar.php"); ?>

        <!-- Content Wrapper -->
        <div class="content-wrapper">
            <!-- Content Header -->
            <section class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1><i class="fas fa-user-check"></i> KYC Review - <?php echo htmlspecialchars($client->name); ?></h1>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="pages_dashboard.php">Dashboard</a></li>
                                <li class="breadcrumb-item"><a href="pages_kyc_management.php">KYC Management</a></li>
                                <li class="breadcrumb-item active">Review</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    
                    <!-- Client Information -->
                    <div class="row">
                        <div class="col-md-8">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title"><i class="fas fa-user"></i> Client Information</h3>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <strong>Name:</strong> <?php echo htmlspecialchars($client->name); ?><br>
                                            <strong>Client Number:</strong> <?php echo $client->client_number; ?><br>
                                            <strong>National ID:</strong> <?php echo $client->national_id; ?><br>
                                            <strong>Phone:</strong> <?php echo $client->phone; ?><br>
                                            <strong>Email:</strong> <?php echo htmlspecialchars($client->email); ?><br>
                                            <strong>Address:</strong> <?php echo htmlspecialchars($client->address); ?>
                                        </div>
                                        <div class="col-md-6">
                                            <strong>Date of Birth:</strong> <?php echo $client->date_of_birth ? date('M d, Y', strtotime($client->date_of_birth)) : 'Not provided'; ?><br>
                                            <strong>Occupation:</strong> <?php echo htmlspecialchars($client->occupation ?? 'Not provided'); ?><br>
                                            <strong>Monthly Income:</strong> <?php echo htmlspecialchars($client->monthly_income ?? 'Not provided'); ?><br>
                                            <strong>Source of Funds:</strong> <?php echo htmlspecialchars($client->source_of_funds ?? 'Not provided'); ?><br>
                                            <strong>Emergency Contact:</strong> <?php echo htmlspecialchars($client->emergency_contact_name ?? 'Not provided'); ?><br>
                                            <strong>Emergency Phone:</strong> <?php echo htmlspecialchars($client->emergency_contact_phone ?? 'Not provided'); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title"><i class="fas fa-info-circle"></i> KYC Status</h3>
                                </div>
                                <div class="card-body text-center">
                                    <h4>
                                        <?php
                                        $status = $client->kyc_status ?? 'pending';
                                        switch($status) {
                                            case 'pending':
                                                echo '<span class="badge badge-warning badge-lg">Pending</span>';
                                                break;
                                            case 'under_review':
                                                echo '<span class="badge badge-info badge-lg">Under Review</span>';
                                                break;
                                            case 'approved':
                                                echo '<span class="badge badge-success badge-lg">Approved</span>';
                                                break;
                                            case 'rejected':
                                                echo '<span class="badge badge-danger badge-lg">Rejected</span>';
                                                break;
                                        }
                                        ?>
                                    </h4>
                                    <p class="text-muted">
                                        <?php if ($client->kyc_submitted_at): ?>
                                            Submitted: <?php echo date('M d, Y H:i', strtotime($client->kyc_submitted_at)); ?>
                                        <?php else: ?>
                                            Not submitted yet
                                        <?php endif; ?>
                                    </p>
                                    
                                    <?php if ($status == 'under_review'): ?>
                                    <div class="mt-3">
                                        <button type="button" class="btn btn-success btn-sm" onclick="updateKYCStatus('approved')">
                                            <i class="fas fa-check"></i> Approve
                                        </button>
                                        <button type="button" class="btn btn-danger btn-sm" onclick="showRejectModal()">
                                            <i class="fas fa-times"></i> Reject
                                        </button>
                                    </div>
                                    <?php endif; ?>
                                    
                                    <?php if ($status == 'rejected' && $client->kyc_rejection_reason): ?>
                                    <div class="alert alert-danger mt-3">
                                        <strong>Rejection Reason:</strong><br>
                                        <?php echo htmlspecialchars($client->kyc_rejection_reason); ?>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Documents Section -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title"><i class="fas fa-file-alt"></i> Uploaded Documents</h3>
                                </div>
                                <div class="card-body">
                                    <?php if ($docs_result->num_rows > 0): ?>
                                        <div class="row">
                                            <?php while ($doc = $docs_result->fetch_object()): ?>
                                                <div class="col-md-6 mb-4">
                                                    <div class="card border-left-primary">
                                                        <div class="card-body">
                                                            <div class="d-flex justify-content-between align-items-start">
                                                                <div>
                                                                    <h6 class="font-weight-bold">
                                                                        <?php echo ucwords(str_replace('_', ' ', $doc->document_type)); ?>
                                                                    </h6>
                                                                    <p class="text-muted mb-1">
                                                                        <small><?php echo htmlspecialchars($doc->document_name); ?></small>
                                                                    </p>
                                                                    <p class="text-muted mb-2">
                                                                        <small>Uploaded: <?php echo date('M d, Y H:i', strtotime($doc->upload_date)); ?></small>
                                                                    </p>
                                                                    <span class="badge <?php 
                                                                        echo $doc->verification_status == 'verified' ? 'badge-success' : 
                                                                            ($doc->verification_status == 'rejected' ? 'badge-danger' : 'badge-warning'); 
                                                                    ?>">
                                                                        <?php echo ucfirst($doc->verification_status); ?>
                                                                    </span>
                                                                </div>
                                                                <div class="text-right">
                                                                    <a href="<?php echo $doc->file_path; ?>" target="_blank" class="btn btn-sm btn-outline-primary">
                                                                        <i class="fas fa-eye"></i> View
                                                                    </a>
                                                                    <?php if ($doc->verification_status == 'pending'): ?>
                                                                    <div class="btn-group mt-2" role="group">
                                                                        <button type="button" class="btn btn-sm btn-success" 
                                                                                onclick="verifyDocument(<?php echo $doc->doc_id; ?>, 'verified')">
                                                                            <i class="fas fa-check"></i>
                                                                        </button>
                                                                        <button type="button" class="btn btn-sm btn-danger" 
                                                                                onclick="showDocRejectModal(<?php echo $doc->doc_id; ?>)">
                                                                            <i class="fas fa-times"></i>
                                                                        </button>
                                                                    </div>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                            <?php if ($doc->verification_status == 'rejected' && $doc->rejection_reason): ?>
                                                                <div class="alert alert-danger mt-2 mb-0">
                                                                    <small><strong>Rejection Reason:</strong> <?php echo htmlspecialchars($doc->rejection_reason); ?></small>
                                                                </div>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endwhile; ?>
                                        </div>
                                    <?php else: ?>
                                        <div class="text-center py-4">
                                            <i class="fas fa-file-upload fa-3x text-muted mb-3"></i>
                                            <p class="text-muted">No documents uploaded yet.</p>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Activity Log -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title"><i class="fas fa-history"></i> Activity Log</h3>
                                </div>
                                <div class="card-body">
                                    <?php if ($log_result->num_rows > 0): ?>
                                        <div class="timeline">
                                            <?php while ($log = $log_result->fetch_object()): ?>
                                                <div class="time-label">
                                                    <span class="bg-primary"><?php echo date('M d, Y', strtotime($log->timestamp)); ?></span>
                                                </div>
                                                <div>
                                                    <i class="fas fa-user bg-info"></i>
                                                    <div class="timeline-item">
                                                        <span class="time"><i class="fas fa-clock"></i> <?php echo date('H:i', strtotime($log->timestamp)); ?></span>
                                                        <h3 class="timeline-header">
                                                            <?php echo htmlspecialchars($log->action); ?>
                                                            by <?php echo htmlspecialchars($log->admin_name ?? $log->staff_name); ?>
                                                        </h3>
                                                        <div class="timeline-body">
                                                            <?php echo htmlspecialchars($log->details ?? ''); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endwhile; ?>
                                            <div>
                                                <i class="fas fa-clock bg-gray"></i>
                                            </div>
                                        </div>
                                    <?php else: ?>
                                        <p class="text-muted text-center">No activity recorded yet.</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </section>
        </div>

        <?php include("dist/_partials/footer.php"); ?>
    </div>

    <!-- KYC Rejection Modal -->
    <div class="modal fade" id="rejectModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Reject KYC Verification</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="status" value="rejected">
                        <div class="form-group">
                            <label>Rejection Reason *</label>
                            <textarea name="rejection_reason" class="form-control" rows="4" 
                                      placeholder="Please provide a clear reason for rejection..." required></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        <button type="submit" name="update_kyc_status" class="btn btn-danger">Reject KYC</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Document Rejection Modal -->
    <div class="modal fade" id="docRejectModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Reject Document</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="doc_id" id="reject_doc_id">
                        <input type="hidden" name="verification_status" value="rejected">
                        <div class="form-group">
                            <label>Rejection Reason *</label>
                            <textarea name="document_rejection_reason" class="form-control" rows="3" 
                                      placeholder="Why is this document being rejected?" required></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        <button type="submit" name="verify_document" class="btn btn-danger">Reject Document</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="plugins/jquery/jquery.min.js"></script>
    <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="dist/js/adminlte.min.js"></script>

    <script>
        function updateKYCStatus(status) {
            if (confirm('Are you sure you want to ' + status + ' this KYC verification?')) {
                var form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = 
                    '<input type="hidden" name="status" value="' + status + '">' +
                    '<input type="hidden" name="update_kyc_status" value="1">';
                document.body.appendChild(form);
                form.submit();
            }
        }

        function showRejectModal() {
            $('#rejectModal').modal('show');
        }

        function verifyDocument(docId, status) {
            if (confirm('Are you sure you want to verify this document?')) {
                var form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = 
                    '<input type="hidden" name="doc_id" value="' + docId + '">' +
                    '<input type="hidden" name="verification_status" value="' + status + '">' +
                    '<input type="hidden" name="verify_document" value="1">';
                document.body.appendChild(form);
                form.submit();
            }
        }

        function showDocRejectModal(docId) {
            document.getElementById('reject_doc_id').value = docId;
            $('#docRejectModal').modal('show');
        }
    </script>
</body>
</html>
