<?php
include("admin/conf/config.php");
/* Persist System Settings On Brand */
$ret = "SELECT * FROM `iB_SystemSettings` ";
$stmt = $mysqli->prepare($ret);
$stmt->execute(); //ok
$res = $stmt->get_result();
while ($sys = $res->fetch_object()) {
?>
    <!DOCTYPE html>
    <html lang="en">
    <meta http-equiv="content-type" content="text/html;charset=utf-8" />

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">
        <title><?php echo $sys->sys_name; ?> - <?php echo $sys->sys_tagline; ?></title>
        <link href="dist/css/custom.css" rel="stylesheet">
        <link href="dist/css/robust.css" rel="stylesheet">
    </head>

    <body>

        <nav class="navbar navbar-expand-lg navbar-dark bg-dark py-3">
            <div class="container">
                <a class="navbar-brand font-weight-bold" href="index.php">Rexxa Trust</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <ul class="navbar-nav ml-auto align-items-center">
                        <li class="nav-item">
                            <a class="nav-link text-white" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="#kyc">KYC Verification</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="About us.php">About Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="reviews.php">Reviews</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="Contact.php">Contact Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" target="_blank" href="admin/pages_index.php">Admin Portal</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" target="_blank" href="staff/pages_staff_index.php">Staff Portal</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" target="_blank" href="client/pages_client_index.php">Client Portal</a>
                        </li>
                    </ul>
                    <a class="btn btn-danger ml-3" href="client/pages_client_signup.php" target="_blank">Join Us</a>
                </div>
            </div>
        </nav>

        <div class="intro py-5 py-lg-9 position-relative text-white">
            <div class="bg-overlay-gray">
                <img src="dist/bg.webp" class="img-fluid img-cover" />
            </div>
            <div class="intro-content py-6 text-center">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-12 col-sm-10 col-md-8 col-lg-6 mx-auto text-center">
                            <h1 class="my-3 display-4 d-none d-lg-inline-block">Welcome To Rexxa Trust</h1>
                            <p class="lead mb-3">
                                Empowering Your Financial Future with Rexxa Trust.
                            </p>
                            <br>
                            <a class="btn btn-primary btn-lg mr-lg-2 my-1" target="_blank" href="client/pages_client_signup.php" role="button">Get started</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Feature Section -->
        <div class="features-section bg-white py-5">
            <div class="container">
                <div class="row gy-4">
                    <div class="col-xl-3 col-sm-6">
                        <div class="feature-card rounded-3 text-center">
                            <div class="icon mb-3">
                                <i class="fas fa-file-invoice-dollar fa-2x text-white"></i>
                            </div>
                            <h3 class="title">Online Payment</h3>
                            <p>We have online payment services like PayPal, Stripe, Paystack, Skrill, Flutterwave, Mollie, Payeer, RazorPay, etc.</p>
                        </div>
                    </div>
                    <div class="col-xl-3 col-sm-6">
                        <div class="feature-card rounded-3 text-center">
                            <div class="icon mb-3">
                                <i class="fas fa-coins fa-2x text-white"></i>
                            </div>
                            <h3 class="title">Take Loan</h3>
                            <p>We have several plans to apply for a loan. You may apply to our loan plans by submitting some of your valid information.</p>
                        </div>
                    </div>
                    <div class="col-xl-3 col-sm-6">
                        <div class="feature-card rounded-3 text-center">
                            <div class="icon mb-3">
                                <i class="fas fa-wallet fa-2x text-white"></i>
                            </div>
                            <h3 class="title">Deposit Schemes</h3>
                            <p>We have two deposit schemes for you, one is Deposit Pension Scheme and another one is the Fixed Deposit Receipt.</p>
                        </div>
                    </div>
                    <div class="col-xl-3 col-sm-6">
                        <div class="feature-card rounded-3 text-center">
                            <div class="icon mb-3">
                                <i class="fas fa-exchange-alt fa-2x text-white"></i>
                            </div>
                            <h3 class="title">Transfer Money</h3>
                            <p>You are able to transfer your funds within the Rexxa Trust or other banks we support by adding your beneficiaries</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- About Us Section -->
        <section id="about" class="about-section py-5 bg-light">
            <div class="container">
                <div class="row align-items-center">
                    <!-- Full-width Image -->
                    <div class="col-lg-6">
                        <div class="about-image">
                            <img src="https://instantmoneyclaims.org/assets/images/frontend/about/60c75675a19651623676533.jpg" alt="About Us" class="img-fluid rounded-3 shadow-lg">
                        </div>
                    </div>
                    <!-- Content Section -->
                    <div class="col-lg-6">
                        <div class="about-content ps-lg-5">
                            <h2 class="section-title mb-4">We Care About Your Money and Safety</h2>
                            <p class="mb-4">At Rexxa Trust, we are dedicated to providing secure and reliable banking services that prioritize your financial well-being and peace of mind.</p>
                            <div class="row gy-4">
                                <!-- Mission Card -->
                                <div class="col-12">
                                    <div class="about-card d-flex align-items-start p-4 bg-white rounded-3 shadow-sm">
                                        <div class="icon bg-primary text-white rounded-circle me-3">
                                            <i class="las la-hourglass-start fa-2x"></i>
                                        </div>
                                        <div>
                                            <h4 class="card-title">Our Mission</h4>
                                            <p class="card-text">To deliver fast, secure, and transparent banking services, empowering our clients to achieve their financial goals with confidence.</p>
                                        </div>
                                    </div>
                                </div>
                                <!-- Vision Card -->
                                <div class="col-12">
                                    <div class="about-card d-flex align-items-start p-4 bg-white rounded-3 shadow-sm">
                                        <div class="icon bg-success text-white rounded-circle me-3">
                                            <i class="far fa-eye fa-2x"></i>
                                        </div>
                                        <div>
                                            <h4 class="card-title">Our Vision</h4>
                                            <p class="card-text">To be a global leader in banking services, known for innovation, security, and exceptional customer satisfaction.</p>
                                        </div>
                                    </div>
                                </div>
                                <!-- Goal Card -->
                                <div class="col-12">
                                    <div class="about-card d-flex align-items-start p-4 bg-white rounded-3 shadow-sm">
                                        <div class="icon bg-warning text-white rounded-circle me-3">
                                            <i class="las la-bullseye fa-2x"></i>
                                        </div>
                                        <div>
                                            <h4 class="card-title">Our Goal</h4>
                                            <p class="card-text">To provide seamless and secure banking solutions that help individuals and businesses thrive in a dynamic financial landscape.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- KYC Verification Section -->
        <section id="kyc" class="kyc-section py-5 bg-gradient-primary">
            <div class="container">
                <!-- Section Header -->
                <div class="row justify-content-center">
                    <div class="col-lg-8 text-center">
                        <div class="section-header">
                            <h2 class="section-title text-white">KYC Verification - Your Security Matters</h2>
                            <p class="section-subtitle text-white">Complete your Know Your Customer (KYC) verification for enhanced security and full access to all our banking services.</p>
                        </div>
                    </div>
                </div>

                <!-- KYC Content -->
                <div class="row gy-4 mt-4">
                    <!-- KYC Overview -->
                    <div class="col-lg-6">
                        <div class="kyc-content bg-white p-4 rounded-3 shadow-lg h-100">
                            <div class="kyc-icon mb-3 text-primary">
                                <i class="fas fa-user-shield fa-3x"></i>
                            </div>
                            <h4 class="kyc-title">What is KYC Verification?</h4>
                            <p class="kyc-description">
                                KYC (Know Your Customer) is a mandatory verification process that helps us:
                            </p>
                            <ul class="kyc-benefits">
                                <li><i class="fas fa-check-circle text-success me-2"></i>Verify your identity and prevent fraud</li>
                                <li><i class="fas fa-check-circle text-success me-2"></i>Comply with international banking regulations</li>
                                <li><i class="fas fa-check-circle text-success me-2"></i>Protect your account from unauthorized access</li>
                                <li><i class="fas fa-check-circle text-success me-2"></i>Enable higher transaction limits</li>
                            </ul>
                        </div>
                    </div>

                    <!-- KYC Process -->
                    <div class="col-lg-6">
                        <div class="kyc-content bg-white p-4 rounded-3 shadow-lg h-100">
                            <div class="kyc-icon mb-3 text-success">
                                <i class="fas fa-clipboard-list fa-3x"></i>
                            </div>
                            <h4 class="kyc-title">Simple 3-Step Process</h4>
                            <div class="kyc-steps">
                                <div class="step-item d-flex align-items-center mb-3">
                                    <div class="step-number bg-primary text-white rounded-circle me-3">1</div>
                                    <div class="step-content">
                                        <h6 class="step-title mb-1">Create Account</h6>
                                        <p class="step-desc mb-0">Sign up for your Rexxa Trust account</p>
                                    </div>
                                </div>
                                <div class="step-item d-flex align-items-center mb-3">
                                    <div class="step-number bg-primary text-white rounded-circle me-3">2</div>
                                    <div class="step-content">
                                        <h6 class="step-title mb-1">Upload Documents</h6>
                                        <p class="step-desc mb-0">Submit valid ID and proof of address</p>
                                    </div>
                                </div>
                                <div class="step-item d-flex align-items-center">
                                    <div class="step-number bg-primary text-white rounded-circle me-3">3</div>
                                    <div class="step-content">
                                        <h6 class="step-title mb-1">Get Verified</h6>
                                        <p class="step-desc mb-0">Our team reviews and approves within 24-48 hours</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Required Documents -->
                <div class="row gy-4 mt-4">
                    <div class="col-lg-12">
                        <div class="kyc-documents bg-white p-4 rounded-3 shadow-lg">
                            <div class="text-center mb-4">
                                <div class="kyc-icon mb-3 text-warning">
                                    <i class="fas fa-file-alt fa-3x"></i>
                                </div>
                                <h4 class="kyc-title">Required Documents</h4>
                                <p class="kyc-description">Please prepare the following documents for verification:</p>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="document-card text-center p-3 border rounded">
                                        <i class="fas fa-id-card fa-2x text-primary mb-2"></i>
                                        <h6>Identity Document</h6>
                                        <small>Passport, National ID, or Driver's License</small>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="document-card text-center p-3 border rounded">
                                        <i class="fas fa-home fa-2x text-success mb-2"></i>
                                        <h6>Proof of Address</h6>
                                        <small>Utility Bill, Bank Statement, or Lease Agreement</small>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="document-card text-center p-3 border rounded">
                                        <i class="fas fa-camera fa-2x text-info mb-2"></i>
                                        <h6>Selfie Photo</h6>
                                        <small>Clear photo holding your ID document</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- KYC Benefits -->
                <div class="row gy-4 mt-4">
                    <div class="col-lg-12">
                        <div class="kyc-benefits-section bg-white p-4 rounded-3 shadow-lg">
                            <div class="text-center mb-4">
                                <h4 class="kyc-title">Benefits of KYC Verification</h4>
                                <p class="kyc-description">Unlock the full potential of your Rexxa Trust account</p>
                            </div>
                            <div class="row">
                                <div class="col-md-3 col-sm-6 mb-3">
                                    <div class="benefit-item text-center">
                                        <i class="fas fa-dollar-sign fa-2x text-success mb-2"></i>
                                        <h6>Higher Limits</h6>
                                        <small>Increased transaction and withdrawal limits</small>
                                    </div>
                                </div>
                                <div class="col-md-3 col-sm-6 mb-3">
                                    <div class="benefit-item text-center">
                                        <i class="fas fa-shield-alt fa-2x text-primary mb-2"></i>
                                        <h6>Enhanced Security</h6>
                                        <small>Additional protection for your account</small>
                                    </div>
                                </div>
                                <div class="col-md-3 col-sm-6 mb-3">
                                    <div class="benefit-item text-center">
                                        <i class="fas fa-globe fa-2x text-info mb-2"></i>
                                        <h6>Global Access</h6>
                                        <small>Access to international banking services</small>
                                    </div>
                                </div>
                                <div class="col-md-3 col-sm-6 mb-3">
                                    <div class="benefit-item text-center">
                                        <i class="fas fa-star fa-2x text-warning mb-2"></i>
                                        <h6>Premium Features</h6>
                                        <small>Exclusive access to premium banking features</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Call to Action -->
                <div class="row mt-5">
                    <div class="col-lg-12 text-center">
                        <div class="kyc-cta bg-white p-5 rounded-3 shadow-lg">
                            <h3 class="cta-title text-dark mb-3">Ready to Get Verified?</h3>
                            <p class="cta-text text-dark mb-4">
                                Join thousands of verified customers enjoying secure and unlimited banking services.
                                Complete your KYC verification today and unlock the full potential of your account.
                            </p>
                            <div class="cta-buttons">
                                <a href="client/pages_client_signup.php" class="btn btn-primary btn-lg me-3" target="_blank">
                                    <i class="fas fa-user-plus me-2"></i>Create Account
                                </a>
                                <a href="client/pages_client_index.php" class="btn btn-outline-primary btn-lg" target="_blank">
                                    <i class="fas fa-sign-in-alt me-2"></i>Login to Verify
                                </a>
                            </div>
                            <div class="security-note mt-4">
                                <small class="text-muted">
                                    <i class="fas fa-lock me-1"></i>
                                    Your documents are encrypted and stored securely. We never share your information with third parties.
                                </small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- filepath: /c:/xampp/htdocs/Internet-banking/index.php -->
        <!-- Services Section -->
        <section id="services" class="services-section bg-light py-5">
            <div class="container">
                <!-- Section Header -->
                <div class="row justify-content-center">
                    <div class="col-lg-8 text-center">
                        <div class="section-header">
                            <h2 class="section-title">Our Services</h2>
                            <p class="section-subtitle">We provide a wide range of services to make your banking experience seamless and secure.</p>
                        </div>
                    </div>
                </div>
                <!-- Services Cards -->
                <div class="row gy-4 mt-4">
                    <!-- Service Card 1 -->
                    <div class="col-lg-4 col-md-6">
                        <div class="service-card text-center p-4 rounded-3 shadow-sm">
                            <div class="service-icon mb-3">
                                <i class="fas fa-exchange-alt"></i>
                            </div>
                            <h4 class="service-title">Fast Transfers</h4>
                            <p class="service-description">Transfer funds securely and instantly within Rexxa Trust or to other supported banks.</p>
                        </div>
                    </div>
                    <!-- Service Card 2 -->
                    <div class="col-lg-4 col-md-6">
                        <div class="service-card text-center p-4 rounded-3 shadow-sm">
                            <div class="service-icon mb-3">
                                <i class="fas fa-piggy-bank"></i>
                            </div>
                            <h4 class="service-title">Savings Accounts</h4>
                            <p class="service-description">Open a savings account with competitive interest rates and secure your future.</p>
                        </div>
                    </div>
                    <!-- Service Card 3 -->
                    <div class="col-lg-4 col-md-6">
                        <div class="service-card text-center p-4 rounded-3 shadow-sm">
                            <div class="service-icon mb-3">
                                <i class="fas fa-credit-card"></i>
                            </div>
                            <h4 class="service-title">Credit Services</h4>
                            <p class="service-description">Access credit services with flexible repayment options tailored to your needs.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Testimonials Section -->
        <section id="testimonials" class="testimonials-section bg-white py-5">
            <div class="container">
                <!-- Section Header -->
                <div class="row justify-content-center">
                    <div class="col-lg-8 text-center">
                        <div class="section-header">
                            <h2 class="section-title">What Our Clients Say</h2>
                            <p class="section-subtitle">Hear from our satisfied customers about their experience with us.</p>
                        </div>
                    </div>
                </div>
                <!-- Testimonials -->
                <div class="row gy-4 mt-4">
                    <!-- Testimonial 1 -->
                    <div class="col-lg-4 col-md-6">
                        <div class="testimonial-card text-center p-4 rounded-3 shadow-sm">
                            <p class="testimonial-text">"Rexxa Trust has transformed the way I manage my finances. Their services are fast, secure, and reliable!"</p>
                            <h5 class="testimonial-author">- John Doe</h5>
                        </div>
                    </div>
                    <!-- Testimonial 2 -->
                    <div class="col-lg-4 col-md-6">
                        <div class="testimonial-card text-center p-4 rounded-3 shadow-sm">
                            <p class="testimonial-text">"I love the simplicity and efficiency of Rexxa Trust. Highly recommended for anyone looking for a trustworthy bank."</p>
                            <h5 class="testimonial-author">- Jane Smith</h5>
                        </div>
                    </div>
                    <!-- Testimonial 3 -->
                    <div class="col-lg-4 col-md-6">
                        <div class="testimonial-card text-center p-4 rounded-3 shadow-sm">
                            <p class="testimonial-text">"Their customer support is exceptional. They helped me resolve my issue in no time!"</p>
                            <h5 class="testimonial-author">- Michael Brown</h5>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Call to Action Section -->
        <section id="cta" class="cta-section bg-primary text-white py-5">
            <div class="container text-center">
                <h2 class="cta-title">Ready to Get Started?</h2>
                <p class="cta-text">Join Rexxa Trust today and experience the best banking services tailored to your needs.</p>
                <a href="https://rexxatrust.com/client/pages_client_signup.php" class="btn btn-light btn-lg">Sign Up Now</a>
            </div>
        </section>
        <!-- Why Choose Us Section -->
        <section id="why-choose-us" class="why-choose-us-section bg-gradient py-5">
            <div class="container">
                <!-- Section Header -->
                <div class="row justify-content-center">
                    <div class="col-lg-8 text-center">
                        <div class="section-header">
                            <h2 class="section-title text-dark">Why Choose Rexxa Trust?</h2>
                            <p class="section-subtitle text-dark">Discover what makes us the best choice for your banking needs.</p>
                        </div>
                    </div>
                </div>
                <!-- Features -->
                <div class="row gy-4 mt-4">
                    <!-- Feature 1 -->
                    <div class="col-lg-4 col-md-6">
                        <div class="feature-card text-center p-4 rounded-3 shadow-lg bg-white">
                            <div class="feature-icon mb-3 text-primary">
                                <i class="fas fa-shield-alt fa-4x"></i>
                            </div>
                            <h4 class="feature-title mt-3">Secure Banking</h4>
                            <p class="feature-description">We prioritize your security with advanced encryption and fraud prevention measures, ensuring your peace of mind.</p>
                        </div>
                    </div>
                    <!-- Feature 2 -->
                    <div class="col-lg-4 col-md-6">
                        <div class="feature-card text-center p-4 rounded-3 shadow-lg bg-white">
                            <div class="feature-icon mb-3 text-success">
                                <i class="fas fa-clock fa-4x"></i>
                            </div>
                            <h4 class="feature-title mt-3">24/7 Support</h4>
                            <p class="feature-description">Our dedicated support team is available around the clock to assist you with any queries or concerns.</p>
                        </div>
                    </div>
                    <!-- Feature 3 -->
                    <div class="col-lg-4 col-md-6">
                        <div class="feature-card text-center p-4 rounded-3 shadow-lg bg-white">
                            <div class="feature-icon mb-3 text-warning">
                                <i class="fas fa-thumbs-up fa-4x"></i>
                            </div>
                            <h4 class="feature-title mt-3">Customer Satisfaction</h4>
                            <p class="feature-description">We are committed to providing exceptional service and ensuring your satisfaction with every interaction.</p>
                        </div>
                    </div>
                </div>
                <!-- Additional Features -->
                <div class="row gy-4 mt-4">
                    <!-- Feature 4 -->
                    <div class="col-lg-4 col-md-6">
                        <div class="feature-card text-center p-4 rounded-3 shadow-lg bg-white">
                            <div class="feature-icon mb-3 text-info">
                                <i class="fas fa-mobile-alt fa-4x"></i>
                            </div>
                            <h4 class="feature-title mt-3">Mobile Banking</h4>
                            <p class="feature-description">Access your account anytime, anywhere with our user-friendly mobile banking app.</p>
                        </div>
                    </div>
                    <!-- Feature 5 -->
                    <div class="col-lg-4 col-md-6">
                        <div class="feature-card text-center p-4 rounded-3 shadow-lg bg-white">
                            <div class="feature-icon mb-3 text-danger">
                                <i class="fas fa-piggy-bank fa-4x"></i>
                            </div>
                            <h4 class="feature-title mt-3">Savings Plans</h4>
                            <p class="feature-description">Choose from a variety of savings plans designed to help you achieve your financial goals.</p>
                        </div>
                    </div>
                    <!-- Feature 6 -->
                    <div class="col-lg-4 col-md-6">
                        <div class="feature-card text-center p-4 rounded-3 shadow-lg bg-white">
                            <div class="feature-icon mb-3 text-secondary">
                                <i class="fas fa-globe fa-4x"></i>
                            </div>
                            <h4 class="feature-title mt-3">Global Reach</h4>
                            <p class="feature-description">Enjoy seamless banking services across the globe with our extensive network and partnerships.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- FAQ Section -->
        <section id="faq" class="faq-section bg-light py-5">
            <div class="container">
                <!-- Section Header -->
                <div class="row justify-content-center">
                    <div class="col-lg-8 text-center">
                        <div class="section-header">
                            <h2 class="section-title">Frequently Asked Questions</h2>
                            <p class="section-subtitle">Find answers to the most common questions about our services.</p>
                        </div>
                    </div>
                </div>
                <!-- FAQ Items -->
                <div class="row gy-4 mt-4">
                    <!-- FAQ 1 -->
                    <div class="col-lg-6">
                        <div class="faq-item">
                            <h5 class="faq-question">How do I open an account?</h5>
                            <p class="faq-answer">You can open an account by clicking the "Sign Up" button and filling out the registration form.</p>
                        </div>
                    </div>
                    <!-- FAQ 2 -->
                    <div class="col-lg-6">
                        <div class="faq-item">
                            <h5 class="faq-question">Is my money safe with Rexxa Trust?</h5>
                            <p class="faq-answer">Yes, we use advanced security measures to ensure your funds and personal information are safe.</p>
                        </div>
                    </div>
                    <!-- FAQ 3 -->
                    <div class="col-lg-6">
                        <div class="faq-item">
                            <h5 class="faq-question">What payment methods do you support?</h5>
                            <p class="faq-answer">We support various payment methods, including PayPal, Stripe, Skrill, and more.</p>
                        </div>
                    </div>
                    <!-- FAQ 4 - KYC Related -->
                    <div class="col-lg-6">
                        <div class="faq-item">
                            <h5 class="faq-question">What is KYC verification and do I need it?</h5>
                            <p class="faq-answer">KYC (Know Your Customer) is a mandatory verification process required by banking regulations. It helps us verify your identity and ensure account security. All clients must complete KYC verification to access full banking services.</p>
                        </div>
                    </div>
                    <!-- FAQ 5 - KYC Documents -->
                    <div class="col-lg-6">
                        <div class="faq-item">
                            <h5 class="faq-question">What documents do I need for KYC verification?</h5>
                            <p class="faq-answer">You need a valid government-issued ID (passport, national ID, or driver's license), proof of address (utility bill or bank statement), and a clear selfie photo holding your ID document.</p>
                        </div>
                    </div>
                    <!-- FAQ 6 - KYC Timeline -->
                    <div class="col-lg-6">
                        <div class="faq-item">
                            <h5 class="faq-question">How long does KYC verification take?</h5>
                            <p class="faq-answer">Our team typically reviews and approves KYC documents within 24-48 hours. You'll receive email notifications about your verification status throughout the process.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Statistics Section -->
        <section id="stats" class="stats-section bg-primary text-white py-5">
            <div class="container">
                <div class="row text-center">
                    <div class="col-lg-3 col-md-6 mb-4">
                        <div class="stat-item">
                            <i class="fas fa-users fa-3x mb-3"></i>
                            <h3 class="stat-number">50,000+</h3>
                            <p class="stat-label">Happy Customers</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 mb-4">
                        <div class="stat-item">
                            <i class="fas fa-dollar-sign fa-3x mb-3"></i>
                            <h3 class="stat-number">$2.5B+</h3>
                            <p class="stat-label">Total Transactions</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 mb-4">
                        <div class="stat-item">
                            <i class="fas fa-globe fa-3x mb-3"></i>
                            <h3 class="stat-number">100+</h3>
                            <p class="stat-label">Countries Served</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 mb-4">
                        <div class="stat-item">
                            <i class="fas fa-award fa-3x mb-3"></i>
                            <h3 class="stat-number">15+</h3>
                            <p class="stat-label">Years of Excellence</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Security Features Section -->
        <section id="security" class="security-section bg-white py-5">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-8 text-center">
                        <div class="section-header">
                            <h2 class="section-title">Bank-Level Security</h2>
                            <p class="section-subtitle">Your security is our top priority. We use cutting-edge technology to protect your financial data.</p>
                        </div>
                    </div>
                </div>
                <div class="row gy-4 mt-4">
                    <div class="col-lg-4 col-md-6">
                        <div class="security-card text-center p-4 rounded-3 shadow-sm">
                            <div class="security-icon mb-3 text-primary">
                                <i class="fas fa-lock fa-3x"></i>
                            </div>
                            <h4 class="security-title">256-Bit SSL Encryption</h4>
                            <p class="security-description">All data transmission is protected with military-grade encryption technology.</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="security-card text-center p-4 rounded-3 shadow-sm">
                            <div class="security-icon mb-3 text-success">
                                <i class="fas fa-user-shield fa-3x"></i>
                            </div>
                            <h4 class="security-title">Two-Factor Authentication</h4>
                            <p class="security-description">Extra layer of security with SMS and email verification for all transactions.</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="security-card text-center p-4 rounded-3 shadow-sm">
                            <div class="security-icon mb-3 text-warning">
                                <i class="fas fa-eye fa-3x"></i>
                            </div>
                            <h4 class="security-title">Real-Time Monitoring</h4>
                            <p class="security-description">24/7 fraud detection system monitors all account activities for suspicious behavior.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- News & Updates Section -->
        <section id="news" class="news-section bg-light py-5">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-8 text-center">
                        <div class="section-header">
                            <h2 class="section-title">Latest News & Updates</h2>
                            <p class="section-subtitle">Stay informed about our latest features and financial insights.</p>
                        </div>
                    </div>
                </div>
                <div class="row gy-4 mt-4">
                    <div class="col-lg-4 col-md-6">
                        <div class="news-card bg-white rounded-3 shadow-sm overflow-hidden">
                            <div class="news-icon-wrapper text-center py-4" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                                <i class="fas fa-mobile-alt fa-4x text-white"></i>
                            </div>
                            <div class="news-content p-4">
                                <span class="news-date text-muted">January 15, 2025</span>
                                <h5 class="news-title mt-2">New Mobile App Features Released</h5>
                                <p class="news-excerpt">Experience enhanced mobile banking with our latest app update featuring improved security and user interface.</p>
                                <a href="#" class="btn btn-outline-primary btn-sm">Read More</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="news-card bg-white rounded-3 shadow-sm overflow-hidden">
                            <div class="news-icon-wrapper text-center py-4" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);">
                                <i class="fas fa-percentage fa-4x text-white"></i>
                            </div>
                            <div class="news-content p-4">
                                <span class="news-date text-muted">December 28, 2024</span>
                                <h5 class="news-title mt-2">Interest Rate Update</h5>
                                <p class="news-excerpt">We're pleased to announce improved interest rates on savings accounts, effective from January 1st, 2025.</p>
                                <a href="#" class="btn btn-outline-primary btn-sm">Read More</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="news-card bg-white rounded-3 shadow-sm overflow-hidden">
                            <div class="news-icon-wrapper text-center py-4" style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);">
                                <i class="fas fa-calendar-alt fa-4x text-white"></i>
                            </div>
                            <div class="news-content p-4">
                                <span class="news-date text-muted">December 20, 2024</span>
                                <h5 class="news-title mt-2">Holiday Banking Hours</h5>
                                <p class="news-excerpt">Please note our special operating hours during the holiday season to better serve our customers.</p>
                                <a href="#" class="btn btn-outline-primary btn-sm">Read More</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Partnership Section -->
        <section id="partners" class="partners-section bg-white py-5">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-8 text-center">
                        <div class="section-header">
                            <h2 class="section-title">Trusted Partners</h2>
                            <p class="section-subtitle">We collaborate with leading financial institutions and technology providers worldwide.</p>
                        </div>
                    </div>
                </div>
                <div class="row align-items-center mt-4">
                    <div class="col-lg-2 col-md-4 col-6 text-center mb-4">
                        <div class="partner-card p-3 rounded shadow-sm bg-light">
                            <i class="fab fa-cc-visa fa-4x text-primary mb-2"></i>
                            <h6 class="partner-name">Visa</h6>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-6 text-center mb-4">
                        <div class="partner-card p-3 rounded shadow-sm bg-light">
                            <i class="fab fa-cc-mastercard fa-4x text-danger mb-2"></i>
                            <h6 class="partner-name">MasterCard</h6>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-6 text-center mb-4">
                        <div class="partner-card p-3 rounded shadow-sm bg-light">
                            <i class="fab fa-cc-paypal fa-4x text-info mb-2"></i>
                            <h6 class="partner-name">PayPal</h6>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-6 text-center mb-4">
                        <div class="partner-card p-3 rounded shadow-sm bg-light">
                            <i class="fab fa-stripe fa-4x text-success mb-2"></i>
                            <h6 class="partner-name">Stripe</h6>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-6 text-center mb-4">
                        <div class="partner-card p-3 rounded shadow-sm bg-light">
                            <i class="fas fa-university fa-4x text-warning mb-2"></i>
                            <h6 class="partner-name">Swift</h6>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-6 text-center mb-4">
                        <div class="partner-card p-3 rounded shadow-sm bg-light">
                            <i class="fab fa-skype fa-4x text-secondary mb-2"></i>
                            <h6 class="partner-name">Skrill</h6>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Contact Information Section -->
        <section id="contact-info" class="contact-info-section bg-gradient py-5">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-8 text-center">
                        <div class="section-header">
                            <h2 class="section-title text-dark">Get In Touch</h2>
                            <p class="section-subtitle text-dark">We're here to help you with all your banking needs.</p>
                        </div>
                    </div>
                </div>
                <div class="row gy-4 mt-4">
                    <div class="col-lg-4 col-md-6">
                        <div class="contact-card text-center p-4 rounded-3 shadow-sm bg-white">
                            <div class="contact-icon mb-3 text-primary">
                                <i class="fas fa-phone fa-3x"></i>
                            </div>
                            <h4 class="contact-title">Call Us</h4>
                            <p class="contact-info">+1 (386) 703-5135</p>
                            <p class="contact-hours text-muted">Mon-Fri: 9:00 AM - 6:00 PM</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="contact-card text-center p-4 rounded-3 shadow-sm bg-white">
                            <div class="contact-icon mb-3 text-success">
                                <i class="fas fa-envelope fa-3x"></i>
                            </div>
                            <h4 class="contact-title">Email Us</h4>
                            <p class="contact-info">info@rexxatrust.com</p>
                            <p class="contact-hours text-muted">24/7 Support Available</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="contact-card text-center p-4 rounded-3 shadow-sm bg-white">
                            <div class="contact-icon mb-3 text-warning">
                                <i class="fas fa-map-marker-alt fa-3x"></i>
                            </div>
                            <h4 class="contact-title">Visit Us</h4>
                            <p class="contact-info">1020 Kinney St<br>Richmond, VA 23220</p>
                            <p class="contact-hours text-muted">Mon-Fri: 9:00 AM - 5:00 PM</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Newsletter Signup Section -->
        <section id="newsletter" class="newsletter-section bg-dark text-white py-5">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <h3 class="newsletter-title">Stay Updated</h3>
                        <p class="newsletter-subtitle">Subscribe to our newsletter and get the latest financial news and updates.</p>
                    </div>
                    <div class="col-lg-6">
                        <form class="newsletter-form">
                            <div class="input-group">
                                <input type="email" class="form-control" placeholder="Enter your email address" required>
                                <button class="btn btn-primary" type="submit">Subscribe</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>

        <!-- Footer Section -->
        <footer class="footer bg-dark text-white py-4">
            <div class="container">
                <div class="row">
                    <!-- About Section -->
                    <div class="col-lg-4 col-md-6 mb-4">
                        <h5 class="footer-title">About Rexxa Trust</h5>
                        <p>Rexxa Trust is committed to providing secure and reliable banking services to help you manage your finances with ease.</p>
                    </div>
                    <!-- Quick Links -->
                    <div class="col-lg-4 col-md-6 mb-4">
                        <h5 class="footer-title">Quick Links</h5>
                        <ul class="footer-links list-unstyled">
                            <li><a href="index.php" class="text-white">Home</a></li>
                            <li><a href="About us.php" class="text-white">About Us</a></li>
                            <li><a href="Contact.php" class="text-white">Contact Us</a></li>
                            <li><a href="https://rexxatrust.com/client/pages_client_signup.php" class="text-white">Sign Up</a></li>
                        </ul>
                    </div>
                    <!-- Social Media -->
                    <div class="col-lg-4 col-md-12 mb-4">
                        <h5 class="footer-title">Follow Us</h5>
                        <div class="social-icons">
                            <a href="#" class="text-white me-3"><i class="fab fa-facebook-f"></i></a>
                            <a href="#" class="text-white me-3"><i class="fab fa-twitter"></i></a>
                            <a href="#" class="text-white me-3"><i class="fab fa-instagram"></i></a>
                            <a href="#" class="text-white"><i class="fab fa-linkedin-in"></i></a>
                        </div>
                    </div>
                </div>
                <div class="row mt-4">
                    <div class="col-12 text-center">
                        <p class="mb-0">&copy; <?php echo date('Y'); ?> Rexxa Trust. All Rights Reserved.</p>
                    </div>
                </div>
            </div>
        </footer>

        <!-- Scroll to Top Button -->
        <button class="scroll-to-top" id="scrollToTop">
            <i class="fas fa-arrow-up"></i>
        </button>

        <script src="dist/js/bundle.js"></script>
        
        <!-- KYC Section Enhancement Scripts -->
        <script>
            // Smooth scrolling for navigation links
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function (e) {
                    e.preventDefault();
                    const target = document.querySelector(this.getAttribute('href'));
                    if (target) {
                        target.scrollIntoView({
                            behavior: 'smooth',
                            block: 'start'
                        });
                    }
                });
            });

            // Scroll to Top Button
            const scrollToTopBtn = document.getElementById('scrollToTop');
            
            window.addEventListener('scroll', function() {
                if (window.pageYOffset > 300) {
                    scrollToTopBtn.classList.add('show');
                } else {
                    scrollToTopBtn.classList.remove('show');
                }
            });

            scrollToTopBtn.addEventListener('click', function() {
                window.scrollTo({
                    top: 0,
                    behavior: 'smooth'
                });
            });

            // Intersection Observer for animations
            const observerOptions = {
                threshold: 0.1,
                rootMargin: '0px 0px -50px 0px'
            };

            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.style.opacity = '1';
                        entry.target.style.transform = 'translateY(0)';
                    }
                });
            }, observerOptions);

            // Observe KYC section elements
            document.addEventListener('DOMContentLoaded', function() {
                const kycElements = document.querySelectorAll('.kyc-content, .kyc-documents, .kyc-benefits-section, .kyc-cta');
                kycElements.forEach(el => {
                    el.style.opacity = '0';
                    el.style.transform = 'translateY(30px)';
                    el.style.transition = 'opacity 0.6s ease-out, transform 0.6s ease-out';
                    observer.observe(el);
                });

                // Add hover effects to benefit items
                const benefitItems = document.querySelectorAll('.benefit-item');
                benefitItems.forEach(item => {
                    item.addEventListener('mouseenter', function() {
                        this.style.transform = 'translateY(-5px)';
                        this.style.transition = 'transform 0.3s ease';
                    });
                    
                    item.addEventListener('mouseleave', function() {
                        this.style.transform = 'translateY(0)';
                    });
                });

                // Add counter animation for statistics
                const statNumbers = document.querySelectorAll('.stat-number');
                statNumbers.forEach(stat => {
                    const finalNumber = stat.textContent;
                    const number = parseInt(finalNumber.replace(/[^\d]/g, ''));
                    const suffix = finalNumber.replace(/[\d,]/g, '');
                    
                    if (number) {
                        animateNumber(stat, 0, number, suffix, 2000);
                    }
                });
            });

            // Number animation function
            function animateNumber(element, start, end, suffix, duration) {
                const observer = new IntersectionObserver((entries) => {
                    entries.forEach(entry => {
                        if (entry.isIntersecting) {
                            let startTime = null;
                            
                            function animate(timestamp) {
                                if (!startTime) startTime = timestamp;
                                const progress = Math.min((timestamp - startTime) / duration, 1);
                                const current = Math.floor(progress * end);
                                
                                element.textContent = current.toLocaleString() + suffix;
                                
                                if (progress < 1) {
                                    requestAnimationFrame(animate);
                                }
                            }
                            
                            requestAnimationFrame(animate);
                            observer.unobserve(element);
                        }
                    });
                });
                
                observer.observe(element);
            }

            // Add active class to navigation on scroll
            window.addEventListener('scroll', function() {
                const sections = document.querySelectorAll('section[id]');
                const navLinks = document.querySelectorAll('.navbar-nav .nav-link[href^="#"]');
                
                let current = '';
                sections.forEach(section => {
                    const sectionTop = section.offsetTop;
                    const sectionHeight = section.clientHeight;
                    if (pageYOffset >= sectionTop - 200) {
                        current = section.getAttribute('id');
                    }
                });

                navLinks.forEach(link => {
                    link.classList.remove('active');
                    if (link.getAttribute('href') === '#' + current) {
                        link.classList.add('active');
                    }
                });
            });
        </script>
    </body>

    </html>
<?php
} ?>