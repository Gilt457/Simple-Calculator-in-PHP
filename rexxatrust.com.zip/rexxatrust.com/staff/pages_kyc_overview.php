<?php
session_start();
include('conf/config.php');
include('conf/checklogin.php');
check_login();
$staff_id = $_SESSION['staff_id'];

// Get KYC statistics
$kyc_pending = 0;
$kyc_approved = 0;
$kyc_rejected = 0;

$ret = "SELECT COUNT(*) as count FROM iB_clients WHERE kyc_status = 'pending'";
$stmt = $mysqli->prepare($ret);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$kyc_pending = $row['count'];

$ret = "SELECT COUNT(*) as count FROM iB_clients WHERE kyc_status = 'approved'";
$stmt = $mysqli->prepare($ret);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$kyc_approved = $row['count'];

$ret = "SELECT COUNT(*) as count FROM iB_clients WHERE kyc_status = 'rejected'";
$stmt = $mysqli->prepare($ret);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$kyc_rejected = $row['count'];

$total_clients = $kyc_pending + $kyc_approved + $kyc_rejected;
$completion_rate = $total_clients > 0 ? round((($kyc_approved + $kyc_rejected) / $total_clients) * 100, 1) : 0;
?>

<!DOCTYPE html>
<html>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<?php include("dist/_partials/head.php"); ?>

<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed">
  <div class="wrapper">
    <!-- Navbar -->
    <?php include("dist/_partials/nav.php"); ?>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <?php include("dist/_partials/sidebar.php"); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1>KYC Management Overview</h1>
            </div>
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="pages_dashboard.php">Dashboard</a></li>
                <li class="breadcrumb-item"><a href="pages_kyc_overview.php">KYC Management</a></li>
                <li class="breadcrumb-item active">Overview</li>
              </ol>
            </div>
          </div>
        </div><!-- /.container-fluid -->
      </section>

      <!-- Main content -->
      <section class="content">
        <div class="container-fluid">
          <!-- Stats Row -->
          <div class="row">
            <div class="col-lg-3 col-6">
              <div class="small-box bg-warning">
                <div class="inner">
                  <h3><?php echo $kyc_pending; ?></h3>
                  <p>Pending Reviews</p>
                </div>
                <div class="icon">
                  <i class="fas fa-clock"></i>
                </div>
                <a href="pages_kyc_pending.php" class="small-box-footer">
                  More info <i class="fas fa-arrow-circle-right"></i>
                </a>
              </div>
            </div>

            <div class="col-lg-3 col-6">
              <div class="small-box bg-success">
                <div class="inner">
                  <h3><?php echo $kyc_approved; ?></h3>
                  <p>Approved</p>
                </div>
                <div class="icon">
                  <i class="fas fa-check-circle"></i>
                </div>
                <a href="#" class="small-box-footer">
                  More info <i class="fas fa-arrow-circle-right"></i>
                </a>
              </div>
            </div>

            <div class="col-lg-3 col-6">
              <div class="small-box bg-danger">
                <div class="inner">
                  <h3><?php echo $kyc_rejected; ?></h3>
                  <p>Rejected</p>
                </div>
                <div class="icon">
                  <i class="fas fa-times-circle"></i>
                </div>
                <a href="#" class="small-box-footer">
                  More info <i class="fas fa-arrow-circle-right"></i>
                </a>
              </div>
            </div>

            <div class="col-lg-3 col-6">
              <div class="small-box bg-info">
                <div class="inner">
                  <h3><?php echo $completion_rate; ?>%</h3>
                  <p>Completion Rate</p>
                </div>
                <div class="icon">
                  <i class="fas fa-chart-pie"></i>
                </div>
                <a href="#" class="small-box-footer">
                  More info <i class="fas fa-arrow-circle-right"></i>
                </a>
              </div>
            </div>
          </div>

          <!-- KYC Submissions Table -->
          <div class="row">
            <div class="col-12">
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">Recent KYC Submissions</h3>
                  <div class="card-tools">
                    <div class="btn-group">
                      <button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown">
                        Filter Status
                      </button>
                      <div class="dropdown-menu">
                        <a class="dropdown-item" href="?status=all">All Status</a>
                        <a class="dropdown-item" href="?status=pending">Pending</a>
                        <a class="dropdown-item" href="?status=approved">Approved</a>
                        <a class="dropdown-item" href="?status=rejected">Rejected</a>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="card-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>Client Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>KYC Status</th>
                        <th>Submitted Date</th>
                        <th>Last Updated</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      // Filter by status if specified
                      $status_filter = isset($_GET['status']) && $_GET['status'] != 'all' ? $_GET['status'] : '';
                        if ($status_filter) {
                        $ret = "SELECT * FROM iB_clients WHERE kyc_status = ? ORDER BY kyc_submitted_at DESC";
                        $stmt = $mysqli->prepare($ret);
                        $stmt->bind_param('s', $status_filter);
                      } else {
                        $ret = "SELECT * FROM iB_clients WHERE kyc_status IS NOT NULL ORDER BY kyc_submitted_at DESC";
                        $stmt = $mysqli->prepare($ret);
                      }
                      
                      $stmt->execute();
                      $res = $stmt->get_result();
                      $cnt = 1;
                      while ($row = $res->fetch_object()) {
                        // Status badge
                        $status_badge = '';
                        switch ($row->kyc_status) {
                          case 'pending':
                            $status_badge = '<span class="badge badge-warning">Pending</span>';
                            break;
                          case 'approved':
                            $status_badge = '<span class="badge badge-success">Approved</span>';
                            break;
                          case 'rejected':
                            $status_badge = '<span class="badge badge-danger">Rejected</span>';
                            break;
                          default:
                            $status_badge = '<span class="badge badge-secondary">Not Submitted</span>';
                        }
                      ?>
                        <tr>
                          <td><?php echo $cnt; ?></td>
                          <td><?php echo $row->name; ?></td>
                          <td><?php echo $row->email; ?></td>
                          <td><?php echo $row->phone; ?></td>
                          <td><?php echo $status_badge; ?></td>                          <td><?php echo $row->kyc_submitted_at ? date('M d, Y', strtotime($row->kyc_submitted_at)) : 'N/A'; ?></td>
                          <td><?php echo $row->kyc_reviewed_at ? date('M d, Y', strtotime($row->kyc_reviewed_at)) : 'N/A'; ?></td>
                          <td>
                            <?php if ($row->kyc_status == 'pending') { ?>
                              <a class="btn btn-primary btn-sm" href="../admin/pages_kyc_review.php?client_id=<?php echo $row->client_id; ?>" target="_blank">
                                <i class="fas fa-eye"></i>
                                Review
                              </a>
                            <?php } else { ?>
                              <a class="btn btn-info btn-sm" href="pages_view_client.php?client_number=<?php echo $row->client_number; ?>">
                                <i class="fas fa-user"></i>
                                View Client
                              </a>
                            <?php } ?>
                          </td>
                        </tr>
                      <?php 
                        $cnt++;
                      } ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    
    <?php include("dist/_partials/footer.php"); ?>

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
      <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
  </div>
  <!-- ./wrapper -->

  <!-- jQuery -->
  <script src="plugins/jquery/jquery.min.js"></script>
  <!-- Bootstrap 4 -->
  <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- DataTables -->
  <script src="plugins/datatables/jquery.dataTables.js"></script>
  <script src="plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
  <!-- AdminLTE App -->
  <script src="dist/js/adminlte.min.js"></script>
  <!-- AdminLTE for demo purposes -->
  <script src="dist/js/demo.js"></script>
  <!-- page script -->
  <script>
    $(function() {
      $("#example1").DataTable({
        "responsive": true,
        "autoWidth": false,
        "order": [[ 5, "desc" ]]
      });
    });
  </script>
</body>
</html>
