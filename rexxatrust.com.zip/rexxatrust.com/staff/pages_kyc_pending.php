<?php
session_start();
include('conf/config.php');
include('conf/checklogin.php');
check_login();
$staff_id = $_SESSION['staff_id'];
?>

<!DOCTYPE html>
<html>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<?php include("dist/_partials/head.php"); ?>

<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed">
  <div class="wrapper">
    <!-- Navbar -->
    <?php include("dist/_partials/nav.php"); ?>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <?php include("dist/_partials/sidebar.php"); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1>Pending KYC Reviews</h1>
            </div>
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="pages_dashboard.php">Dashboard</a></li>
                <li class="breadcrumb-item"><a href="pages_kyc_overview.php">KYC Management</a></li>
                <li class="breadcrumb-item active">Pending Reviews</li>
              </ol>
            </div>
          </div>
        </div><!-- /.container-fluid -->
      </section>

      <!-- Main content -->
      <section class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-12">
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">
                    <i class="fas fa-clock text-warning"></i>
                    KYC Submissions Pending Review
                  </h3>
                  <div class="card-tools">
                    <span class="badge badge-warning" id="pending-count">
                      <?php
                      $count_query = "SELECT COUNT(*) as count FROM iB_clients WHERE kyc_status = 'pending'";
                      $count_stmt = $mysqli->prepare($count_query);
                      $count_stmt->execute();
                      $count_result = $count_stmt->get_result();
                      $count_row = $count_result->fetch_assoc();
                      echo $count_row['count'];
                      ?>
                      Pending
                    </span>
                  </div>
                </div>
                <div class="card-body">
                  <?php
                  $ret = "SELECT * FROM iB_clients WHERE kyc_status = 'pending' ORDER BY kyc_submitted_at DESC";
                  $stmt = $mysqli->prepare($ret);
                  $stmt->execute();
                  $res = $stmt->get_result();
                  
                  if ($res->num_rows > 0) {
                  ?>
                    <table id="example1" class="table table-bordered table-striped">
                      <thead>
                        <tr>
                          <th>#</th>
                          <th>Client Details</th>
                          <th>Contact Information</th>
                          <th>Submission Info</th>
                          <th>Documents</th>
                          <th>Priority</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                        $cnt = 1;
                        while ($row = $res->fetch_object()) {                          // Calculate days since submission
                          $submission_date = new DateTime($row->kyc_submitted_at);
                          $current_date = new DateTime();
                          $days_pending = $current_date->diff($submission_date)->days;
                          
                          // Determine priority based on days pending
                          $priority_class = '';
                          $priority_text = '';
                          if ($days_pending > 7) {
                            $priority_class = 'badge-danger';
                            $priority_text = 'High';
                          } elseif ($days_pending > 3) {
                            $priority_class = 'badge-warning';
                            $priority_text = 'Medium';
                          } else {
                            $priority_class = 'badge-success';
                            $priority_text = 'Normal';
                          }

                          // Check for uploaded documents
                          $doc_query = "SELECT COUNT(*) as doc_count FROM iB_kyc_documents WHERE client_id = ?";
                          $doc_stmt = $mysqli->prepare($doc_query);
                          $doc_stmt->bind_param('i', $row->client_id);
                          $doc_stmt->execute();
                          $doc_result = $doc_stmt->get_result();
                          $doc_row = $doc_result->fetch_assoc();
                          $doc_count = $doc_row['doc_count'];
                        ?>
                          <tr>
                            <td><?php echo $cnt; ?></td>
                            <td>
                              <strong><?php echo $row->name; ?></strong><br>
                              <small class="text-muted">ID: <?php echo $row->client_number; ?></small><br>
                              <small class="text-muted">National ID: <?php echo $row->national_id; ?></small>
                            </td>
                            <td>
                              <i class="fas fa-envelope"></i> <?php echo $row->email; ?><br>
                              <i class="fas fa-phone"></i> <?php echo $row->phone; ?><br>
                              <i class="fas fa-map-marker-alt"></i> <?php echo substr($row->address, 0, 30) . '...'; ?>
                            </td>                            <td>
                              <strong>Submitted:</strong><br>
                              <?php echo date('M d, Y', strtotime($row->kyc_submitted_at)); ?><br>
                              <small class="text-muted"><?php echo $days_pending; ?> days ago</small>
                            </td>
                            <td class="text-center">
                              <?php if ($doc_count > 0) { ?>
                                <span class="badge badge-success">
                                  <i class="fas fa-file-alt"></i> <?php echo $doc_count; ?> docs
                                </span>
                              <?php } else { ?>
                                <span class="badge badge-secondary">
                                  <i class="fas fa-file-times"></i> No docs
                                </span>
                              <?php } ?>
                            </td>
                            <td>
                              <span class="badge <?php echo $priority_class; ?>">
                                <?php echo $priority_text; ?>
                              </span>
                            </td>
                            <td>
                              <div class="btn-group">
                                <a class="btn btn-primary btn-sm" href="../admin/pages_kyc_review.php?client_id=<?php echo $row->client_id; ?>" target="_blank">
                                  <i class="fas fa-eye"></i>
                                  Review
                                </a>
                                <a class="btn btn-info btn-sm" href="pages_view_client.php?client_number=<?php echo $row->client_number; ?>">
                                  <i class="fas fa-user"></i>
                                  Client
                                </a>
                              </div>
                            </td>
                          </tr>
                        <?php 
                          $cnt++;
                        } ?>
                      </tbody>
                    </table>
                  <?php } else { ?>
                    <div class="text-center py-5">
                      <i class="fas fa-check-circle text-success" style="font-size: 3rem;"></i>
                      <h4 class="mt-3">All Caught Up!</h4>
                      <p class="text-muted">There are no pending KYC reviews at the moment.</p>
                      <a href="pages_kyc_overview.php" class="btn btn-primary">
                        <i class="fas fa-chart-bar"></i> View KYC Overview
                      </a>
                    </div>
                  <?php } ?>
                </div>
              </div>
            </div>
          </div>

          <!-- Quick Actions Card -->
          <div class="row">
            <div class="col-12">
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">
                    <i class="fas fa-bolt"></i>
                    Quick Actions
                  </h3>
                </div>
                <div class="card-body">
                  <div class="row">
                    <div class="col-md-3">
                      <div class="info-box">
                        <span class="info-box-icon bg-warning">
                          <i class="fas fa-clock"></i>
                        </span>
                        <div class="info-box-content">
                          <span class="info-box-text">High Priority</span>
                          <span class="info-box-number">
                            <?php
                            $high_priority = "SELECT COUNT(*) as count FROM iB_clients WHERE kyc_status = 'pending' AND DATEDIFF(NOW(), kyc_submitted_at) > 7";
                            $hp_stmt = $mysqli->prepare($high_priority);
                            $hp_stmt->execute();
                            $hp_result = $hp_stmt->get_result();
                            $hp_row = $hp_result->fetch_assoc();
                            echo $hp_row['count'];
                            ?>
                          </span>
                        </div>
                      </div>
                    </div>

                    <div class="col-md-3">
                      <div class="info-box">
                        <span class="info-box-icon bg-info">
                          <i class="fas fa-file-alt"></i>
                        </span>
                        <div class="info-box-content">
                          <span class="info-box-text">With Documents</span>
                          <span class="info-box-number">
                            <?php
                            $with_docs = "SELECT COUNT(DISTINCT c.client_id) as count FROM iB_clients c 
                                         INNER JOIN iB_kyc_documents d ON c.client_id = d.client_id 
                                         WHERE c.kyc_status = 'pending'";
                            $wd_stmt = $mysqli->prepare($with_docs);
                            $wd_stmt->execute();
                            $wd_result = $wd_stmt->get_result();
                            $wd_row = $wd_result->fetch_assoc();
                            echo $wd_row['count'];
                            ?>
                          </span>
                        </div>
                      </div>
                    </div>

                    <div class="col-md-3">
                      <div class="info-box">
                        <span class="info-box-icon bg-success">
                          <i class="fas fa-chart-line"></i>
                        </span>
                        <div class="info-box-content">
                          <span class="info-box-text">Today's Reviews</span>
                          <span class="info-box-number">                            <?php
                            $today_reviews = "SELECT COUNT(*) as count FROM iB_clients WHERE DATE(kyc_reviewed_at) = CURDATE()";
                            $tr_stmt = $mysqli->prepare($today_reviews);
                            $tr_stmt->execute();
                            $tr_result = $tr_stmt->get_result();
                            $tr_row = $tr_result->fetch_assoc();
                            echo $tr_row['count'];
                            ?>
                          </span>
                        </div>
                      </div>
                    </div>

                    <div class="col-md-3">
                      <div class="info-box">
                        <span class="info-box-icon bg-gradient-primary">
                          <i class="fas fa-users"></i>
                        </span>
                        <div class="info-box-content">
                          <span class="info-box-text">Total Clients</span>
                          <span class="info-box-number">
                            <?php
                            $total_clients = "SELECT COUNT(*) as count FROM iB_clients";
                            $tc_stmt = $mysqli->prepare($total_clients);
                            $tc_stmt->execute();
                            $tc_result = $tc_stmt->get_result();
                            $tc_row = $tc_result->fetch_assoc();
                            echo $tc_row['count'];
                            ?>
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    
    <?php include("dist/_partials/footer.php"); ?>

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
      <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
  </div>
  <!-- ./wrapper -->

  <!-- jQuery -->
  <script src="plugins/jquery/jquery.min.js"></script>
  <!-- Bootstrap 4 -->
  <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- DataTables -->
  <script src="plugins/datatables/jquery.dataTables.js"></script>
  <script src="plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
  <!-- AdminLTE App -->
  <script src="dist/js/adminlte.min.js"></script>
  <!-- AdminLTE for demo purposes -->
  <script src="dist/js/demo.js"></script>
  <!-- page script -->
  <script>
    $(function() {
      $("#example1").DataTable({
        "responsive": true,
        "autoWidth": false,
        "order": [[ 3, "desc" ]],
        "pageLength": 25
      });
    });
  </script>
</body>
</html>
