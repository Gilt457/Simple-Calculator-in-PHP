<?php
include("admin/conf/config.php");
/* Persist System Settings On Brand */
$ret = "SELECT * FROM `iB_SystemSettings` ";
$stmt = $mysqli->prepare($ret);
$stmt->execute();
$res = $stmt->get_result();
while ($sys = $res->fetch_object()) {
?>
    <!DOCTYPE html>
    <html lang="en">
    <meta http-equiv="content-type" content="text/html;charset=utf-8" />

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="Learn more about <?php echo $sys->sys_name; ?>, our mission, vision, and values.">
        <meta name="author" content="">
        <title>About Us - <?php echo $sys->sys_name; ?></title>
        <link href="dist/css/custom.css" rel="stylesheet">
        <link href="dist/css/robust.css" rel="stylesheet">
        <link href="dist/css/about us.css" rel="stylesheet">
    </head>

    <body>

        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark py-3">
            <div class="container">
                <a class="navbar-brand font-weight-bold" href="index.php"><?php echo $sys->sys_name; ?></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <ul class="navbar-nav ml-auto align-items-center">
                        <li class="nav-item">
                            <a class="nav-link text-white" href="index.php">Home</a>
                        </li>                        <li class="nav-item">
                            <a class="nav-link text-white" href="About us.php">About Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="reviews.php">Reviews</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="Contact.php">Contact Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" target="_blank" href="admin/pages_index.php">Admin Portal</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" target="_blank" href="staff/pages_staff_index.php">Staff Portal</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" target="_blank" href="client/pages_client_index.php">Client Portal</a>
                        </li>
                    </ul>
                    <a class="btn btn-danger ml-3" href="client/pages_client_signup.php" target="_blank">Join Us</a>
                </div>
            </div>
        </nav>

        <!-- Intro Section -->
        <div class="intro py-4 position-relative text-white" style="background-color: #343a40;">
            <div class="intro-content py-4 text-center">
                <div class="container">                    <h1 class="my-3 display-5">Rexxa Trust - About Us</h1>
                    <p class="lead mb-2">Learn more about our mission, vision, and values.</p>
                </div>
            </div>
        </div>


        <!-- About Us Section -->
        <section id="about" class="about-section py-5 bg-light">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6 mb-4 mb-lg-0">
                        <div class="image-wrapper position-relative">
                            <img src="https://instantmoneyclaims.org/assets/images/frontend/about/60c75675a19651623676533.jpg" alt="About Us" class="img-fluid rounded-3 shadow-lg">
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <h2 class="section-title mb-4 text-primary">Who We Are</h2>                        <p class="text-muted">At <strong>Rexxa Trust</strong>, we are dedicated to providing secure and innovative banking solutions tailored to meet the needs of individuals and businesses. With a strong focus on customer satisfaction, we strive to deliver exceptional services that empower our clients to achieve their financial goals.</p>
                        <p class="text-muted">Our team of experienced professionals is committed to upholding the highest standards of integrity, transparency, and excellence in everything we do.</p>
                        <a href="https://rexxatrust.com/Contact.php" class="btn btn-primary mt-3">Contact Us</a>
                    </div>
                </div>
            </div>
        </section>

        <!-- Mission, Vision, and Goal Section -->
        <section class="mission-vision-section py-5">
            <div class="container">
                <div class="section-header text-center mb-5">
                    <h2 class="text-uppercase text-primary">Our Mission, Vision, and Goal</h2>
                    <p class="text-muted">Discover what drives us to deliver exceptional banking services.</p>
                </div>
                <div class="row">
                    <div class="col-lg-4">
                        <div class="card mission-card shadow-sm">
                            <div class="card-body text-center">
                                <div class="icon-wrapper mb-4">
                                    <i class="fas fa-bullseye fa-3x text-primary"></i>
                                </div>
                                <h4 class="card-title">Our Mission</h4>
                                <p class="card-text">To deliver fast, secure, and transparent banking services, empowering our clients to achieve their financial goals with confidence.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="card mission-card shadow-sm">
                            <div class="card-body text-center">
                                <div class="icon-wrapper mb-4">
                                    <i class="fas fa-eye fa-3x text-success"></i>
                                </div>
                                <h4 class="card-title">Our Vision</h4>
                                <p class="card-text">To be a global leader in banking services, known for innovation, security, and exceptional customer satisfaction.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="card mission-card shadow-sm">
                            <div class="card-body text-center">
                                <div class="icon-wrapper mb-4">
                                    <i class="fas fa-handshake fa-3x text-warning"></i>
                                </div>
                                <h4 class="card-title">Our Goal</h4>
                                <p class="card-text">To provide seamless and secure banking solutions that help individuals and businesses thrive in a dynamic financial landscape.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- filepath: /c:/xampp/htdocs/Internet-banking/About us.php -->
        <!-- Core Values Section -->
        <section class="core-values-section py-5 bg-light">
            <div class="container">
                <div class="section-header text-center mb-5">
                    <h2 class="text-uppercase text-primary">Our Core Values</h2>
                    <p class="text-muted">The principles that guide us in delivering exceptional banking services.</p>
                </div>
                <div class="row">
                    <div class="col-lg-4">
                        <div class="card value-card shadow-sm">
                            <div class="card-body text-center">
                                <div class="icon-wrapper mb-4">
                                    <i class="fas fa-shield-alt fa-3x text-primary"></i>
                                </div>
                                <h4 class="card-title">Integrity</h4>
                                <p class="card-text">We uphold the highest standards of honesty and transparency in all our dealings.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="card value-card shadow-sm">
                            <div class="card-body text-center">
                                <div class="icon-wrapper mb-4">
                                    <i class="fas fa-lightbulb fa-3x text-success"></i>
                                </div>
                                <h4 class="card-title">Innovation</h4>
                                <p class="card-text">We embrace creativity and technology to deliver cutting-edge banking solutions.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="card value-card shadow-sm">
                            <div class="card-body text-center">
                                <div class="icon-wrapper mb-4">
                                    <i class="fas fa-users fa-3x text-warning"></i>
                                </div>
                                <h4 class="card-title">Customer Focus</h4>
                                <p class="card-text">Our clients are at the heart of everything we do, ensuring their satisfaction and success.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Meet Our Team Section -->
        <section class="team-section py-5">
            <div class="container">
                <div class="section-header text-center mb-5">
                    <h2 class="text-uppercase text-primary">Meet Our Team</h2>
                    <p class="text-muted">The dedicated professionals behind our success.</p>
                </div>
                <div class="row">
                    <div class="col-lg-3 col-md-6 mb-4">
                        <div class="card team-card shadow-sm">
                            <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80" alt="John Doe - CEO" class="card-img-top rounded-circle mx-auto mt-4" style="width: 120px; height: 120px; object-fit: cover;">
                            <div class="card-body text-center">
                                <h5 class="card-title">John Doe</h5>
                                <p class="card-text text-muted">Chief Executive Officer</p>
                                <p class="small text-muted">15+ years in financial services leadership</p>
                                <div class="social-links mt-2">
                                    <a href="#" class="text-primary me-2"><i class="fab fa-linkedin"></i></a>
                                    <a href="#" class="text-info"><i class="fab fa-twitter"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 mb-4">
                        <div class="card team-card shadow-sm">
                            <img src="https://images.unsplash.com/photo-1494790108755-2616b612b1e5?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80" alt="Jane Smith - CFO" class="card-img-top rounded-circle mx-auto mt-4" style="width: 120px; height: 120px; object-fit: cover;">
                            <div class="card-body text-center">
                                <h5 class="card-title">Jane Smith</h5>
                                <p class="card-text text-muted">Chief Financial Officer</p>
                                <p class="small text-muted">CPA with 12+ years in banking finance</p>
                                <div class="social-links mt-2">
                                    <a href="#" class="text-primary me-2"><i class="fab fa-linkedin"></i></a>
                                    <a href="#" class="text-info"><i class="fab fa-twitter"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 mb-4">
                        <div class="card team-card shadow-sm">
                            <img src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80" alt="Michael Brown - CTO" class="card-img-top rounded-circle mx-auto mt-4" style="width: 120px; height: 120px; object-fit: cover;">
                            <div class="card-body text-center">
                                <h5 class="card-title">Michael Brown</h5>
                                <p class="card-text text-muted">Chief Technology Officer</p>
                                <p class="small text-muted">Expert in fintech and cybersecurity</p>
                                <div class="social-links mt-2">
                                    <a href="#" class="text-primary me-2"><i class="fab fa-linkedin"></i></a>
                                    <a href="#" class="text-info"><i class="fab fa-twitter"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 mb-4">
                        <div class="card team-card shadow-sm">
                            <img src="https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80" alt="Emily Davis - COO" class="card-img-top rounded-circle mx-auto mt-4" style="width: 120px; height: 120px; object-fit: cover;">
                            <div class="card-body text-center">
                                <h5 class="card-title">Emily Davis</h5>
                                <p class="card-text text-muted">Chief Operating Officer</p>
                                <p class="small text-muted">Operations excellence and process optimization</p>
                                <div class="social-links mt-2">
                                    <a href="#" class="text-primary me-2"><i class="fab fa-linkedin"></i></a>
                                    <a href="#" class="text-info"><i class="fab fa-twitter"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Our History Section -->
        <section class="history-section py-5 bg-light">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6">                        <h2 class="section-title mb-4 text-primary">Our Journey</h2>
                        <p class="text-muted">Founded in 2010, Rexxa Trust began as a small financial services company with a vision to revolutionize banking. Over the years, we have grown into a trusted institution serving thousands of clients worldwide.</p>
                        <div class="timeline mt-4">
                            <div class="timeline-item mb-3">
                                <strong class="text-primary">2010:</strong> Company founded with 5 employees
                            </div>
                            <div class="timeline-item mb-3">
                                <strong class="text-primary">2015:</strong> Launched online banking platform
                            </div>
                            <div class="timeline-item mb-3">
                                <strong class="text-primary">2020:</strong> Reached 10,000+ active clients
                            </div>
                            <div class="timeline-item mb-3">
                                <strong class="text-primary">2025:</strong> Expanded to serve international markets
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <img src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80" alt="Our History" class="img-fluid rounded-3 shadow-lg">
                    </div>
                </div>
            </div>
        </section>

        <!-- Services Overview Section -->
        <section class="services-overview py-5">
            <div class="container">
                <div class="section-header text-center mb-5">
                    <h2 class="text-uppercase text-primary">What We Offer</h2>
                    <p class="text-muted">Comprehensive banking solutions tailored to your needs.</p>
                </div>
                <div class="row">
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="service-item text-center p-4 h-100 bg-white shadow-sm rounded">
                            <i class="fas fa-credit-card fa-3x text-primary mb-3"></i>
                            <h5>Personal Banking</h5>
                            <p class="text-muted">Savings accounts, checking accounts, and personal loans designed for individuals.</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="service-item text-center p-4 h-100 bg-white shadow-sm rounded">
                            <i class="fas fa-building fa-3x text-success mb-3"></i>
                            <h5>Business Banking</h5>
                            <p class="text-muted">Corporate accounts, business loans, and merchant services for growing businesses.</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="service-item text-center p-4 h-100 bg-white shadow-sm rounded">
                            <i class="fas fa-mobile-alt fa-3x text-warning mb-3"></i>
                            <h5>Digital Banking</h5>
                            <p class="text-muted">24/7 online and mobile banking with advanced security features.</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="service-item text-center p-4 h-100 bg-white shadow-sm rounded">
                            <i class="fas fa-chart-line fa-3x text-info mb-3"></i>
                            <h5>Investment Services</h5>
                            <p class="text-muted">Wealth management and investment planning to help grow your assets.</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="service-item text-center p-4 h-100 bg-white shadow-sm rounded">
                            <i class="fas fa-home fa-3x text-danger mb-3"></i>
                            <h5>Mortgage Solutions</h5>
                            <p class="text-muted">Home loans and refinancing options with competitive rates.</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="service-item text-center p-4 h-100 bg-white shadow-sm rounded">
                            <i class="fas fa-headset fa-3x text-secondary mb-3"></i>
                            <h5>24/7 Support</h5>
                            <p class="text-muted">Round-the-clock customer service to assist you whenever you need help.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Statistics Section -->
        <section class="stats-section py-5" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
            <div class="container">
                <div class="row text-center text-white">
                    <div class="col-lg-3 col-md-6 mb-4">
                        <div class="stat-item">
                            <i class="fas fa-users fa-3x mb-3"></i>
                            <h2 class="stat-number">15,000+</h2>
                            <p>Happy Clients</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 mb-4">
                        <div class="stat-item">
                            <i class="fas fa-dollar-sign fa-3x mb-3"></i>
                            <h2 class="stat-number">$2.5B+</h2>
                            <p>Assets Under Management</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 mb-4">
                        <div class="stat-item">
                            <i class="fas fa-globe fa-3x mb-3"></i>
                            <h2 class="stat-number">25+</h2>
                            <p>Countries Served</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 mb-4">
                        <div class="stat-item">
                            <i class="fas fa-award fa-3x mb-3"></i>
                            <h2 class="stat-number">50+</h2>
                            <p>Industry Awards</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Security & Compliance Section -->
        <section class="security-section py-5 bg-light">
            <div class="container">
                <div class="section-header text-center mb-5">
                    <h2 class="text-uppercase text-primary">Security & Compliance</h2>
                    <p class="text-muted">Your security is our top priority.</p>
                </div>
                <div class="row align-items-center">
                    <div class="col-lg-6 mb-4 mb-lg-0">
                        <img src="https://images.unsplash.com/photo-1563013544-824ae1b704d3?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80" alt="Security" class="img-fluid rounded-3 shadow-lg">
                    </div>
                    <div class="col-lg-6">
                        <h3 class="mb-4">Bank-Level Security</h3>
                        <div class="security-features">
                            <div class="feature-item d-flex align-items-center mb-3">
                                <i class="fas fa-lock text-primary me-3 fa-2x"></i>
                                <div>
                                    <h5 class="mb-1">256-bit SSL Encryption</h5>
                                    <p class="text-muted mb-0">All data transmitted is protected with military-grade encryption.</p>
                                </div>
                            </div>
                            <div class="feature-item d-flex align-items-center mb-3">
                                <i class="fas fa-shield-alt text-success me-3 fa-2x"></i>
                                <div>
                                    <h5 class="mb-1">FDIC Insured</h5>
                                    <p class="text-muted mb-0">Your deposits are protected up to $250,000 by FDIC insurance.</p>
                                </div>
                            </div>
                            <div class="feature-item d-flex align-items-center mb-3">
                                <i class="fas fa-eye text-warning me-3 fa-2x"></i>
                                <div>
                                    <h5 class="mb-1">24/7 Monitoring</h5>
                                    <p class="text-muted mb-0">Continuous fraud detection and account monitoring.</p>
                                </div>
                            </div>
                            <div class="feature-item d-flex align-items-center">
                                <i class="fas fa-check-circle text-info me-3 fa-2x"></i>
                                <div>
                                    <h5 class="mb-1">Regulatory Compliance</h5>
                                    <p class="text-muted mb-0">Fully compliant with all banking regulations and standards.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Customer Testimonials Section -->
        <section class="testimonials-section py-5">
            <div class="container">
                <div class="section-header text-center mb-5">
                    <h2 class="text-uppercase text-primary">What Our Clients Say</h2>
                    <p class="text-muted">Real feedback from our valued customers.</p>
                </div>
                <div class="row">
                    <div class="col-lg-4 mb-4">
                        <div class="testimonial-card card h-100 shadow-sm">
                            <div class="card-body text-center">
                                <div class="stars mb-3">
                                    <i class="fas fa-star text-warning"></i>
                                    <i class="fas fa-star text-warning"></i>
                                    <i class="fas fa-star text-warning"></i>
                                    <i class="fas fa-star text-warning"></i>
                                    <i class="fas fa-star text-warning"></i>
                                </div>                                <p class="card-text">"Rexxa Trust has transformed how I manage my finances. Their online platform is intuitive and secure."</p>
                                <div class="customer-info mt-3">
                                    <img src="https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80" alt="Sarah Johnson" class="rounded-circle mb-2" style="width: 60px; height: 60px; object-fit: cover;">
                                    <h6 class="mb-0">Sarah Johnson</h6>
                                    <small class="text-muted">Business Owner</small>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="testimonial-card card h-100 shadow-sm">
                            <div class="card-body text-center">
                                <div class="stars mb-3">
                                    <i class="fas fa-star text-warning"></i>
                                    <i class="fas fa-star text-warning"></i>
                                    <i class="fas fa-star text-warning"></i>
                                    <i class="fas fa-star text-warning"></i>
                                    <i class="fas fa-star text-warning"></i>
                                </div>
                                <p class="card-text">"Excellent customer service and competitive rates. I've been banking with them for 5 years and couldn't be happier."</p>
                                <div class="customer-info mt-3">
                                    <img src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80" alt="Mark Thompson" class="rounded-circle mb-2" style="width: 60px; height: 60px; object-fit: cover;">
                                    <h6 class="mb-0">Mark Thompson</h6>
                                    <small class="text-muted">Software Engineer</small>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="testimonial-card card h-100 shadow-sm">
                            <div class="card-body text-center">
                                <div class="stars mb-3">
                                    <i class="fas fa-star text-warning"></i>
                                    <i class="fas fa-star text-warning"></i>
                                    <i class="fas fa-star text-warning"></i>
                                    <i class="fas fa-star text-warning"></i>
                                    <i class="fas fa-star text-warning"></i>
                                </div>
                                <p class="card-text">"Their mobile app is fantastic, and the 24/7 support team is always ready to help. Highly recommended!"</p>
                                <div class="customer-info mt-3">
                                    <img src="https://images.unsplash.com/photo-1494790108755-2616b612b1e5?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80" alt="Lisa Chen" class="rounded-circle mb-2" style="width: 60px; height: 60px; object-fit: cover;">
                                    <h6 class="mb-0">Lisa Chen</h6>
                                    <small class="text-muted">Marketing Director</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Awards & Recognition Section -->
        <section class="awards-section py-5 bg-light">
            <div class="container">
                <div class="section-header text-center mb-5">
                    <h2 class="text-uppercase text-primary">Awards & Recognition</h2>
                    <p class="text-muted">Industry recognition for our excellence in banking services.</p>
                </div>
                <div class="row">
                    <div class="col-lg-3 col-md-6 mb-4">
                        <div class="award-item text-center">
                            <div class="award-icon mb-3">
                                <i class="fas fa-trophy fa-4x text-warning"></i>
                            </div>
                            <h5>Best Digital Bank 2024</h5>
                            <p class="text-muted">Banking Excellence Awards</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 mb-4">
                        <div class="award-item text-center">
                            <div class="award-icon mb-3">
                                <i class="fas fa-medal fa-4x text-primary"></i>
                            </div>
                            <h5>Customer Service Excellence</h5>
                            <p class="text-muted">Financial Services Institute</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 mb-4">
                        <div class="award-item text-center">
                            <div class="award-icon mb-3">
                                <i class="fas fa-star fa-4x text-success"></i>
                            </div>
                            <h5>Innovation in Banking</h5>
                            <p class="text-muted">Tech Finance Summit 2023</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 mb-4">
                        <div class="award-item text-center">
                            <div class="award-icon mb-3">
                                <i class="fas fa-certificate fa-4x text-info"></i>
                            </div>
                            <h5>Security Excellence</h5>
                            <p class="text-muted">Cybersecurity Awards 2024</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Call to Action Section -->
        <section class="cta-section py-5" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-8">                        <h2 class="text-white mb-3">Ready to Join Rexxa Trust?</h2>
                        <p class="text-white mb-0">Experience the future of banking with our secure, innovative, and customer-focused services.</p>
                    </div>
                    <div class="col-lg-4 text-lg-end">
                        <a href="client/pages_client_signup.php" class="btn btn-light btn-lg px-4" target="_blank">
                            <i class="fas fa-user-plus me-2"></i>Open An Account
                        </a>
                    </div>
                </div>
            </div>
        </section>

        <!-- Footer Section -->
        <footer class="footer bg-dark text-white py-4">
            <div class="container">
                <div class="row">                    <!-- About Section -->
                    <div class="col-lg-4 col-md-6 mb-4">
                        <h5 class="footer-title">About Rexxa Trust</h5>
                        <p>Rexxa Trust is committed to providing secure and reliable banking services to help you manage your finances with ease.</p>
                    </div>
                    <!-- Quick Links -->
                    <div class="col-lg-4 col-md-6 mb-4">
                        <h5 class="footer-title">Quick Links</h5>
                        <ul class="footer-links list-unstyled">                            <li><a href="index.php" class="text-white">Home</a></li>
                            <li><a href="About us.php" class="text-white">About Us</a></li>
                            <li><a href="reviews.php" class="text-white">Reviews</a></li>
                            <li><a href="Contact.php" class="text-white">Contact Us</a></li>
                            <li><a href="https://rexxatrust.com/client/pages_client_signup.php" class="text-white">Sign Up</a></li>
                        </ul>
                    </div>
                    <!-- Social Media -->
                    <div class="col-lg-4 col-md-12 mb-4">
                        <h5 class="footer-title">Follow Us</h5>
                        <div class="social-icons">
                            <a href="#" class="text-white me-3"><i class="fab fa-facebook-f"></i></a>
                            <a href="#" class="text-white me-3"><i class="fab fa-twitter"></i></a>
                            <a href="#" class="text-white me-3"><i class="fab fa-instagram"></i></a>
                            <a href="#" class="text-white"><i class="fab fa-linkedin-in"></i></a>
                        </div>
                    </div>
                </div>                <div class="row mt-4">
                    <div class="col-12 text-center">
                        <p class="mb-0">&copy; <?php echo date('Y'); ?> Rexxa Trust. All Rights Reserved.</p>
                    </div>
                </div>
            </div>
        </footer>


        <script src="dist/js/bundle.js"></script>
    </body>

    </html>
<?php
}
?>