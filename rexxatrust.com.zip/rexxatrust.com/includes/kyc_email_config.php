<?php
/**
 * Email Configuration for KYC Notifications
 * 
 * This file contains email settings and functions for sending
 * KYC status change notifications to clients
 */

// Email configuration settings
$email_config = array(
    'smtp_host' => 'localhost', // Change to your SMTP server
    'smtp_port' => 587,
    'smtp_username' => 'noreply@rexxatrust.com', // Change to your email
    'smtp_password' => '', // Add your SMTP password
    'from_email' => 'noreply@rexxatrust.com',
    'from_name' => 'Rexxa Trust Bank - KYC Team',
    'use_smtp' => false // Set to true when SMTP is configured
);

/**
 * Send KYC status change email notification
 * 
 * @param string $to_email Recipient email address
 * @param string $client_name Client's name
 * @param string $status New KYC status (approved/rejected/under_review)
 * @param string $reason Optional reason for rejection
 * @return bool Success status
 */
function sendKYCNotification($to_email, $client_name, $status, $reason = '') {
    global $email_config;
    
    // Email subject based on status
    $subjects = array(
        'approved' => 'KYC Verification Approved - Welcome to Rexxa Trust Bank',
        'rejected' => 'KYC Verification - Additional Information Required',
        'under_review' => 'KYC Verification Under Review - Rexxa Trust Bank'
    );
    
    $subject = isset($subjects[$status]) ? $subjects[$status] : 'KYC Status Update';
    
    // Email body content
    $body = getEmailTemplate($client_name, $status, $reason);
    
    // Email headers
    $headers = array(
        'MIME-Version: 1.0',
        'Content-type: text/html; charset=UTF-8',
        'From: ' . $email_config['from_name'] . ' <' . $email_config['from_email'] . '>',
        'Reply-To: ' . $email_config['from_email'],
        'X-Mailer: PHP/' . phpversion()
    );
    
    try {
        if ($email_config['use_smtp']) {
            // Use SMTP if configured (requires additional SMTP library)
            return sendViaSMTP($to_email, $subject, $body, $headers);
        } else {
            // Use PHP mail function (for development/local testing)
            return mail($to_email, $subject, $body, implode("\r\n", $headers));
        }
    } catch (Exception $e) {
        error_log("KYC Email Error: " . $e->getMessage());
        return false;
    }
}

/**
 * Generate email template based on KYC status
 * 
 * @param string $client_name Client's name
 * @param string $status KYC status
 * @param string $reason Optional rejection reason
 * @return string HTML email template
 */
function getEmailTemplate($client_name, $status, $reason = '') {
    $base_url = 'https://rexxatrust.com'; // Update with your domain
    
    $templates = array(
        'approved' => '
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f9f9f9;">
                <div style="background-color: #ffffff; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
                    <div style="text-align: center; margin-bottom: 30px;">
                        <h1 style="color: #28a745; margin: 0;">✅ KYC Verification Approved</h1>
                    </div>
                    
                    <p style="font-size: 16px; color: #333; line-height: 1.6;">Dear ' . htmlspecialchars($client_name) . ',</p>
                    
                    <p style="font-size: 16px; color: #333; line-height: 1.6;">
                        Congratulations! Your KYC (Know Your Customer) verification has been successfully approved. 
                        You now have full access to all Rexxa Trust Bank services.
                    </p>
                    
                    <div style="background-color: #d4edda; border: 1px solid #c3e6cb; border-radius: 5px; padding: 15px; margin: 20px 0;">
                        <h3 style="color: #155724; margin: 0 0 10px 0;">What you can now do:</h3>
                        <ul style="color: #155724; margin: 0; padding-left: 20px;">
                            <li>Make deposits and withdrawals</li>
                            <li>Transfer funds to other accounts</li>
                            <li>Access premium banking features</li>
                            <li>Apply for loans and credit facilities</li>
                        </ul>
                    </div>
                    
                    <div style="text-align: center; margin: 30px 0;">
                        <a href="' . $base_url . '/client/pages_dashboard.php" 
                           style="background-color: #28a745; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;">
                            Access Your Account
                        </a>
                    </div>
                    
                    <p style="font-size: 14px; color: #666; text-align: center; margin-top: 30px;">
                        Thank you for choosing Rexxa Trust Bank. We look forward to serving you.
                    </p>
                </div>
            </div>
        ',
        
        'rejected' => '
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f9f9f9;">
                <div style="background-color: #ffffff; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
                    <div style="text-align: center; margin-bottom: 30px;">
                        <h1 style="color: #dc3545; margin: 0;">📋 KYC Verification - Additional Information Required</h1>
                    </div>
                    
                    <p style="font-size: 16px; color: #333; line-height: 1.6;">Dear ' . htmlspecialchars($client_name) . ',</p>
                    
                    <p style="font-size: 16px; color: #333; line-height: 1.6;">
                        We have reviewed your KYC submission and require additional information or documentation 
                        to complete the verification process.
                    </p>
                    
                    ' . ($reason ? '
                    <div style="background-color: #f8d7da; border: 1px solid #f5c6cb; border-radius: 5px; padding: 15px; margin: 20px 0;">
                        <h3 style="color: #721c24; margin: 0 0 10px 0;">Reason for Review:</h3>
                        <p style="color: #721c24; margin: 0;">' . htmlspecialchars($reason) . '</p>
                    </div>
                    ' : '') . '
                    
                    <div style="background-color: #d1ecf1; border: 1px solid #bee5eb; border-radius: 5px; padding: 15px; margin: 20px 0;">
                        <h3 style="color: #0c5460; margin: 0 0 10px 0;">Next Steps:</h3>
                        <ul style="color: #0c5460; margin: 0; padding-left: 20px;">
                            <li>Review the feedback provided</li>
                            <li>Update your documents as necessary</li>
                            <li>Resubmit your KYC application</li>
                            <li>Contact our support team if you need assistance</li>
                        </ul>
                    </div>
                    
                    <div style="text-align: center; margin: 30px 0;">
                        <a href="' . $base_url . '/client/pages_kyc_verification.php" 
                           style="background-color: #dc3545; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;">
                            Update KYC Information
                        </a>
                    </div>
                    
                    <p style="font-size: 14px; color: #666; text-align: center; margin-top: 30px;">
                        If you have any questions, please contact our customer support team.
                    </p>
                </div>
            </div>
        ',
        
        'under_review' => '
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f9f9f9;">
                <div style="background-color: #ffffff; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
                    <div style="text-align: center; margin-bottom: 30px;">
                        <h1 style="color: #ffc107; margin: 0;">⏳ KYC Verification Under Review</h1>
                    </div>
                    
                    <p style="font-size: 16px; color: #333; line-height: 1.6;">Dear ' . htmlspecialchars($client_name) . ',</p>
                    
                    <p style="font-size: 16px; color: #333; line-height: 1.6;">
                        Thank you for submitting your KYC (Know Your Customer) documents. We have received your 
                        application and our team is currently reviewing your information.
                    </p>
                    
                    <div style="background-color: #fff3cd; border: 1px solid #ffeaa7; border-radius: 5px; padding: 15px; margin: 20px 0;">
                        <h3 style="color: #856404; margin: 0 0 10px 0;">What happens next:</h3>
                        <ul style="color: #856404; margin: 0; padding-left: 20px;">
                            <li>Our compliance team will review your documents</li>
                            <li>Verification typically takes 1-3 business days</li>
                            <li>You will receive an email notification once complete</li>
                            <li>Limited account access during review period</li>
                        </ul>
                    </div>
                    
                    <div style="text-align: center; margin: 30px 0;">
                        <a href="' . $base_url . '/client/pages_dashboard.php" 
                           style="background-color: #ffc107; color: #212529; padding: 12px 30px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;">
                            Check Status
                        </a>
                    </div>
                    
                    <p style="font-size: 14px; color: #666; text-align: center; margin-top: 30px;">
                        We appreciate your patience during the verification process.
                    </p>
                </div>
            </div>
        '
    );
    
    return isset($templates[$status]) ? $templates[$status] : '';
}

/**
 * SMTP email sending function (placeholder for when SMTP is configured)
 * 
 * @param string $to_email Recipient email
 * @param string $subject Email subject
 * @param string $body Email body
 * @param array $headers Email headers
 * @return bool Success status
 */
function sendViaSMTP($to_email, $subject, $body, $headers) {
    // This would integrate with PHPMailer or similar SMTP library
    // For now, fallback to PHP mail function
    return mail($to_email, $subject, $body, implode("\r\n", $headers));
}

/**
 * Log KYC email activity
 * 
 * @param int $client_id Client ID
 * @param string $status KYC status
 * @param string $email_address Email address
 * @param bool $success Whether email was sent successfully
 */
function logKYCEmail($client_id, $status, $email_address, $success) {
    global $mysqli;
    
    $log_entry = "KYC Email " . ($success ? "sent" : "failed") . " - Status: $status to $email_address";
    
    $query = "INSERT INTO iB_kyc_log (client_id, action, details, created_at) VALUES (?, ?, ?, NOW())";
    $stmt = $mysqli->prepare($query);
    
    if ($stmt) {
        $action = "email_notification";
        $stmt->bind_param('iss', $client_id, $action, $log_entry);
        $stmt->execute();
        $stmt->close();
    }
}
?>
