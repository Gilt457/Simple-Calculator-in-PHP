<?php
include("admin/conf/config.php");
/* Persist System Settings On Brand */
$ret = "SELECT * FROM `iB_SystemSettings` ";
$stmt = $mysqli->prepare($ret);
$stmt->execute();
$res = $stmt->get_result();
while ($sys = $res->fetch_object()) {
?>
    <!DOCTYPE html>
    <html lang="en">
    <meta http-equiv="content-type" content="text/html;charset=utf-8" />

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="Read customer reviews and testimonials about <?php echo $sys->sys_name; ?> banking services.">
        <meta name="author" content="">
        <title>Customer Reviews - <?php echo $sys->sys_name; ?></title>
        <link href="dist/css/custom.css" rel="stylesheet">
        <link href="dist/css/robust.css" rel="stylesheet">
        <link href="dist/css/about us.css" rel="stylesheet">
        <style>
            .review-card {
                transition: transform 0.3s ease, box-shadow 0.3s ease;
                border: none;
                border-radius: 15px;
                overflow: hidden;
            }
            .review-card:hover {
                transform: translateY(-5px);
                box-shadow: 0 10px 30px rgba(0,0,0,0.15);
            }
            .star-rating {
                color: #ffc107;
                font-size: 1.2rem;
                margin-bottom: 15px;
            }
            .reviewer-avatar {
                width: 80px;
                height: 80px;
                border-radius: 50%;
                object-fit: cover;
                border: 4px solid #fff;
                box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            }
            .review-text {
                font-style: italic;
                font-size: 1.1rem;
                line-height: 1.6;
                color: #555;
            }
            .reviewer-info h6 {
                color: #333;
                font-weight: 600;
                margin-bottom: 5px;
            }
            .reviewer-info small {
                color: #6c757d;
                font-weight: 500;
            }
            .hero-section {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                padding: 80px 0;
                color: white;
            }
            .stats-counter {
                font-size: 2.5rem;
                font-weight: bold;
                color: #667eea;
            }
            .filter-btn {
                border: 2px solid #667eea;
                color: #667eea;
                background: transparent;
                border-radius: 25px;
                padding: 8px 20px;
                margin: 5px;
                transition: all 0.3s ease;
            }
            .filter-btn:hover, .filter-btn.active {
                background: #667eea;
                color: white;
            }
            .review-summary {
                background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
                border-radius: 15px;
                padding: 30px;
            }
            .progress-bar-custom {
                height: 8px;
                border-radius: 4px;
                background: #e9ecef;
            }
            .progress-fill {
                height: 100%;
                border-radius: 4px;
                background: linear-gradient(90deg, #ffc107, #ffeb3b);
            }
        </style>
    </head>

    <body>

        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark py-3">
            <div class="container">
                <a class="navbar-brand font-weight-bold" href="index.php"><?php echo $sys->sys_name; ?></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <ul class="navbar-nav ml-auto align-items-center">
                        <li class="nav-item">
                            <a class="nav-link text-white" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="About us.php">About Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="reviews.php">Reviews</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="Contact.php">Contact Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" target="_blank" href="admin/pages_index.php">Admin Portal</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" target="_blank" href="staff/pages_staff_index.php">Staff Portal</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" target="_blank" href="client/pages_client_index.php">Client Portal</a>
                        </li>
                    </ul>
                    <a class="btn btn-danger ml-3" href="client/pages_client_signup.php" target="_blank">Join Us</a>
                </div>
            </div>
        </nav>

        <!-- Hero Section -->
        <section class="hero-section">
            <div class="container text-center">
                <h1 class="display-4 mb-4">Customer Reviews & Testimonials</h1>
                <p class="lead mb-4">Discover what our valued customers say about their banking experience with us</p>
                <div class="row mt-5">
                    <div class="col-md-4">
                        <div class="stats-counter">4.9</div>
                        <p>Average Rating</p>
                    </div>
                    <div class="col-md-4">
                        <div class="stats-counter">2,847</div>
                        <p>Total Reviews</p>
                    </div>
                    <div class="col-md-4">
                        <div class="stats-counter">98%</div>
                        <p>Satisfaction Rate</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- Review Summary Section -->
        <section class="py-5">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 mx-auto">
                        <div class="review-summary">
                            <h3 class="text-center mb-4">Overall Rating Breakdown</h3>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <div class="d-flex justify-content-between align-items-center mb-1">
                                            <span>5 Stars</span>
                                            <span>75%</span>
                                        </div>
                                        <div class="progress-bar-custom">
                                            <div class="progress-fill" style="width: 75%"></div>
                                        </div>
                                    </div>
                                    <div class="mb-3">
                                        <div class="d-flex justify-content-between align-items-center mb-1">
                                            <span>4 Stars</span>
                                            <span>18%</span>
                                        </div>
                                        <div class="progress-bar-custom">
                                            <div class="progress-fill" style="width: 18%"></div>
                                        </div>
                                    </div>
                                    <div class="mb-3">
                                        <div class="d-flex justify-content-between align-items-center mb-1">
                                            <span>3 Stars</span>
                                            <span>5%</span>
                                        </div>
                                        <div class="progress-bar-custom">
                                            <div class="progress-fill" style="width: 5%"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <div class="d-flex justify-content-between align-items-center mb-1">
                                            <span>2 Stars</span>
                                            <span>1%</span>
                                        </div>
                                        <div class="progress-bar-custom">
                                            <div class="progress-fill" style="width: 1%"></div>
                                        </div>
                                    </div>
                                    <div class="mb-3">
                                        <div class="d-flex justify-content-between align-items-center mb-1">
                                            <span>1 Star</span>
                                            <span>1%</span>
                                        </div>
                                        <div class="progress-bar-custom">
                                            <div class="progress-fill" style="width: 1%"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Filter Section -->
        <section class="py-3 bg-light">
            <div class="container">
                <div class="text-center">
                    <h4 class="mb-3">Filter Reviews</h4>
                    <button class="filter-btn active" data-filter="all">All Reviews</button>
                    <button class="filter-btn" data-filter="5-star">5 Star</button>
                    <button class="filter-btn" data-filter="business">Business Banking</button>
                    <button class="filter-btn" data-filter="personal">Personal Banking</button>
                    <button class="filter-btn" data-filter="digital">Digital Services</button>
                    <button class="filter-btn" data-filter="support">Customer Support</button>
                </div>
            </div>
        </section>

        <!-- Featured Reviews Section -->
        <section class="py-5">
            <div class="container">
                <h2 class="text-center mb-5 text-primary">Featured Customer Reviews</h2>
                <div class="row">
                    <!-- Review 1 -->
                    <div class="col-lg-4 col-md-6 mb-4" data-category="5-star digital">
                        <div class="card review-card h-100">
                            <div class="card-body text-center p-4">
                                <div class="star-rating">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </div>
                                <p class="review-text">"The mobile banking app is absolutely fantastic! I can manage all my finances on the go, and the security features give me complete peace of mind. The interface is intuitive and user-friendly."</p>
                                <div class="reviewer-info mt-4">
                                    <img src="https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80" alt="Sarah Mitchell" class="reviewer-avatar mb-3">
                                    <h6>Sarah Mitchell</h6>
                                    <small>Marketing Director</small>
                                    <div class="mt-2">
                                        <small class="text-muted">Customer since 2019</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Review 2 -->
                    <div class="col-lg-4 col-md-6 mb-4" data-category="5-star business">
                        <div class="card review-card h-100">
                            <div class="card-body text-center p-4">
                                <div class="star-rating">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </div>                                <p class="review-text">"Rexxa Trust has been instrumental in growing my business. Their business banking solutions and loan options are competitive, and the support team truly understands our needs."</p>
                                <div class="reviewer-info mt-4">
                                    <img src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80" alt="Robert Chen" class="reviewer-avatar mb-3">
                                    <h6>Robert Chen</h6>
                                    <small>CEO, Tech Innovations Ltd</small>
                                    <div class="mt-2">
                                        <small class="text-muted">Customer since 2018</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Review 3 -->
                    <div class="col-lg-4 col-md-6 mb-4" data-category="5-star support">
                        <div class="card review-card h-100">
                            <div class="card-body text-center p-4">
                                <div class="star-rating">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </div>
                                <p class="review-text">"Exceptional customer service! When I had an issue with my account, their support team resolved it within minutes. Available 24/7 and always professional and courteous."</p>
                                <div class="reviewer-info mt-4">
                                    <img src="https://images.unsplash.com/photo-1494790108755-2616b612b1e5?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80" alt="Amanda Foster" class="reviewer-avatar mb-3">
                                    <h6>Amanda Foster</h6>
                                    <small>Freelance Designer</small>
                                    <div class="mt-2">
                                        <small class="text-muted">Customer since 2020</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Review 4 -->
                    <div class="col-lg-4 col-md-6 mb-4" data-category="5-star personal">
                        <div class="card review-card h-100">
                            <div class="card-body text-center p-4">
                                <div class="star-rating">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </div>                                <p class="review-text">"I've been banking with Rexxa Trust for over 6 years, and they've consistently exceeded my expectations. Great interest rates, transparent fees, and excellent investment advice."</p>
                                <div class="reviewer-info mt-4">
                                    <img src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80" alt="Michael Rodriguez" class="reviewer-avatar mb-3">
                                    <h6>Michael Rodriguez</h6>
                                    <small>Software Engineer</small>
                                    <div class="mt-2">
                                        <small class="text-muted">Customer since 2017</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Review 5 -->
                    <div class="col-lg-4 col-md-6 mb-4" data-category="5-star digital">
                        <div class="card review-card h-100">
                            <div class="card-body text-center p-4">
                                <div class="star-rating">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </div>
                                <p class="review-text">"The online banking platform is incredibly secure and easy to navigate. I love the real-time notifications and the detailed transaction history. Banking has never been this convenient!"</p>
                                <div class="reviewer-info mt-4">
                                    <img src="https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80" alt="Jennifer Park" class="reviewer-avatar mb-3">
                                    <h6>Jennifer Park</h6>
                                    <small>Financial Analyst</small>
                                    <div class="mt-2">
                                        <small class="text-muted">Customer since 2021</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Review 6 -->
                    <div class="col-lg-4 col-md-6 mb-4" data-category="5-star business">
                        <div class="card review-card h-100">
                            <div class="card-body text-center p-4">
                                <div class="star-rating">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </div>
                                <p class="review-text">"Their business loan process was smooth and transparent. The relationship manager assigned to our account provides personalized service and understands our industry challenges."</p>
                                <div class="reviewer-info mt-4">
                                    <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80" alt="David Thompson" class="reviewer-avatar mb-3">
                                    <h6>David Thompson</h6>
                                    <small>Restaurant Owner</small>
                                    <div class="mt-2">
                                        <small class="text-muted">Customer since 2019</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Review 7 -->
                    <div class="col-lg-4 col-md-6 mb-4" data-category="5-star personal">
                        <div class="card review-card h-100">
                            <div class="card-body text-center p-4">
                                <div class="star-rating">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </div>                                <p class="review-text">"Rexxa Trust helped me secure my first home loan with competitive rates and excellent guidance throughout the process. Their mortgage team made everything stress-free."</p>
                                <div class="reviewer-info mt-4">
                                    <img src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80" alt="Lisa Wang" class="reviewer-avatar mb-3">
                                    <h6>Lisa Wang</h6>
                                    <small>Teacher</small>
                                    <div class="mt-2">
                                        <small class="text-muted">Customer since 2022</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Review 8 -->
                    <div class="col-lg-4 col-md-6 mb-4" data-category="5-star support">
                        <div class="card review-card h-100">
                            <div class="card-body text-center p-4">
                                <div class="star-rating">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </div>
                                <p class="review-text">"The customer support team goes above and beyond. They helped me recover from a fraud attempt quickly and efficiently. I feel completely secure banking with them."</p>
                                <div class="reviewer-info mt-4">
                                    <img src="https://images.unsplash.com/photo-1519345182560-3f2917c472ef?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80" alt="James Wilson" class="reviewer-avatar mb-3">
                                    <h6>James Wilson</h6>
                                    <small>Retired</small>
                                    <div class="mt-2">
                                        <small class="text-muted">Customer since 2015</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Review 9 -->
                    <div class="col-lg-4 col-md-6 mb-4" data-category="5-star digital">
                        <div class="card review-card h-100">
                            <div class="card-body text-center p-4">
                                <div class="star-rating">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </div>                                <p class="review-text">"The digital transformation at Rexxa Trust is impressive. From mobile check deposits to instant transfers, everything works seamlessly. They're truly ahead of their time."</p>
                                <div class="reviewer-info mt-4">
                                    <img src="https://images.unsplash.com/photo-1531427186611-ecfd6d936c79?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80" alt="Alex Johnson" class="reviewer-avatar mb-3">
                                    <h6>Alex Johnson</h6>
                                    <small>Tech Consultant</small>
                                    <div class="mt-2">
                                        <small class="text-muted">Customer since 2023</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Call to Action Section -->
        <section class="py-5" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
            <div class="container">
                <div class="row align-items-center text-white">
                    <div class="col-lg-8">
                        <h2 class="mb-3">Join Thousands of Satisfied Customers</h2>
                        <p class="mb-0 lead">Experience the exceptional banking services that our customers rave about. Start your journey with us today.</p>
                    </div>
                    <div class="col-lg-4 text-lg-end">
                        <a href="client/pages_client_signup.php" class="btn btn-light btn-lg px-4 me-3" target="_blank">
                            <i class="fas fa-user-plus me-2"></i>Open Account
                        </a>
                        <a href="Contact.php" class="btn btn-outline-light btn-lg px-4">
                            <i class="fas fa-phone me-2"></i>Contact Us
                        </a>
                    </div>
                </div>
            </div>
        </section>

        <!-- Footer Section -->
        <footer class="footer bg-dark text-white py-4">
            <div class="container">
                <div class="row">                    <!-- About Section -->
                    <div class="col-lg-4 col-md-6 mb-4">
                        <h5 class="footer-title">About Rexxa Trust</h5>
                        <p>Rexxa Trust is committed to providing secure and reliable banking services to help you manage your finances with ease.</p>
                    </div>
                    <!-- Quick Links -->
                    <div class="col-lg-4 col-md-6 mb-4">
                        <h5 class="footer-title">Quick Links</h5>
                        <ul class="footer-links list-unstyled">
                            <li><a href="index.php" class="text-white">Home</a></li>
                            <li><a href="About us.php" class="text-white">About Us</a></li>
                            <li><a href="reviews.php" class="text-white">Reviews</a></li>
                            <li><a href="Contact.php" class="text-white">Contact Us</a></li>
                            <li><a href="client/pages_client_signup.php" class="text-white">Sign Up</a></li>
                        </ul>
                    </div>
                    <!-- Social Media -->
                    <div class="col-lg-4 col-md-12 mb-4">
                        <h5 class="footer-title">Follow Us</h5>
                        <div class="social-icons">
                            <a href="#" class="text-white me-3"><i class="fab fa-facebook-f"></i></a>
                            <a href="#" class="text-white me-3"><i class="fab fa-twitter"></i></a>
                            <a href="#" class="text-white me-3"><i class="fab fa-instagram"></i></a>
                            <a href="#" class="text-white"><i class="fab fa-linkedin-in"></i></a>
                        </div>
                    </div>
                </div>                <div class="row mt-4">
                    <div class="col-12 text-center">
                        <p class="mb-0">&copy; <?php echo date('Y'); ?> Rexxa Trust. All Rights Reserved.</p>
                    </div>
                </div>
            </div>
        </footer>

        <script src="dist/js/bundle.js"></script>
        <script>
            // Filter functionality
            document.addEventListener('DOMContentLoaded', function() {
                const filterButtons = document.querySelectorAll('.filter-btn');
                const reviewCards = document.querySelectorAll('[data-category]');

                filterButtons.forEach(button => {
                    button.addEventListener('click', function() {
                        // Remove active class from all buttons
                        filterButtons.forEach(btn => btn.classList.remove('active'));
                        // Add active class to clicked button
                        this.classList.add('active');

                        const filter = this.getAttribute('data-filter');

                        reviewCards.forEach(card => {
                            if (filter === 'all' || card.getAttribute('data-category').includes(filter)) {
                                card.style.display = 'block';
                                setTimeout(() => {
                                    card.style.opacity = '1';
                                    card.style.transform = 'scale(1)';
                                }, 100);
                            } else {
                                card.style.opacity = '0';
                                card.style.transform = 'scale(0.9)';
                                setTimeout(() => {
                                    card.style.display = 'none';
                                }, 300);
                            }
                        });
                    });
                });
            });
        </script>
    </body>

    </html>
<?php
}
?>
